// ============================================================
// AZX — Admin control plane: approvals queue, gateway audit log,
// platform usage/cost, all-apps registry, CSP violations.
// ============================================================

// ---- Approvals queue ------------------------------------------------
function AdminApprovals(){
  const [done,setDone] = useState({});
  const KIND = {
    'go-public':['globe','Go public'], 'mcp-grant':['key','MCP grant'],
    'origin-grant':['globe','Origin grant'], 'llm-budget':['cpu','LLM budget'],
  };
  const pending = APPROVALS.filter(a=>!done[a.id]);
  return <div className="stagger">
    <PageHead eyebrow="Control plane · elevated" title="Approvals"
      sub="Grants above the baseline — going public, any MCP server, new external origins, high LLM budgets — pause here for a human decision."
      actions={<Badge tone="violet" icon="shield" style={{ fontSize:11 }}>{pending.length} pending</Badge>}/>

    {pending.length===0 && <Card style={{ textAlign:'center', padding:'56px 20px' }}>
      <div style={{ width:52, height:52, borderRadius:14, background:'var(--live-dim)', color:'var(--live)', display:'grid', placeItems:'center', margin:'0 auto 14px' }}><Icon name="check" size={26}/></div>
      <h3 style={{ fontSize:17 }}>Queue clear</h3>
      <p style={{ color:'var(--fg-3)', fontSize:13.5, marginTop:6 }}>No elevated grants awaiting review.</p>
    </Card>}

    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      {pending.map(a=>{ const [ic,label]=KIND[a.kind]; return (
        <Card key={a.id} style={{ display:'grid', gridTemplateColumns:'1fr auto', gap:20 }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10, flexWrap:'wrap' }}>
              <Badge tone="neutral" icon={ic}>{label}</Badge>
              <Risk level={a.risk}/>
              <span className="mono" style={{ fontSize:12, color:'var(--fg-3)', whiteSpace:'nowrap' }}>{a.ago} ago</span>
            </div>
            <h3 style={{ fontSize:16, marginBottom:6 }}>{a.summary}</h3>
            <p style={{ fontSize:13, color:'var(--fg-3)', lineHeight:1.5, maxWidth:560 }}>{a.detail}</p>
            <div style={{ display:'flex', gap:18, marginTop:14, alignItems:'center', flexWrap:'wrap' }}>
              <span style={{ display:'flex', alignItems:'center', gap:7, fontSize:12.5, color:'var(--fg-2)', whiteSpace:'nowrap' }}><Icon name="box" size={14} style={{ color:'var(--fg-3)' }}/><span className="mono" style={{ color:'var(--acc)' }}>{a.app}</span></span>
              <span style={{ display:'flex', alignItems:'center', gap:7, fontSize:12.5, color:'var(--fg-2)', whiteSpace:'nowrap' }}><Icon name="user" size={14} style={{ color:'var(--fg-3)' }}/>{a.owner}</span>
            </div>
            {/* diff */}
            <div style={{ marginTop:14, background:'#06070a', border:'1px solid var(--line)', borderRadius:'var(--r-md)', padding:'12px 14px', fontFamily:'var(--font-mono)', fontSize:12 }}>
              {a.diff.map(([k,from,to],i)=>(
                <div key={i} style={{ display:'flex', flexDirection:'column', gap:3 }}>
                  <div style={{ color:'var(--bad)' }}>- {k}: {from}</div>
                  <div style={{ color:'var(--live)' }}>+ {k}: {to}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:9, justifyContent:'center', minWidth:150 }}>
            <Button variant="primary" icon="check" onClick={()=>setDone(d=>({...d,[a.id]:'approved'}))}>Approve grant</Button>
            <Button variant="ghost" size="md">Request changes</Button>
            <Button variant="danger" size="md" icon="x" onClick={()=>setDone(d=>({...d,[a.id]:'denied'}))}>Deny</Button>
          </div>
        </Card>
      );})}
    </div>
  </div>;
}

// ---- Gateway audit log ---------------------------------------------
function AdminAudit(){
  const [q,setQ] = useState('');
  const [out,setOut] = useState('all');
  const [cap,setCap] = useState('all');
  const OUT = { ok:['live','ok'], blocked:['bad','blocked'], quota:['warn','quota'], denied:['bad','denied'] };
  const rows = AUDIT.filter(r=>{
    if(out!=='all' && r.out!==out) return false;
    if(cap!=='all' && !r.cap.startsWith(cap)) return false;
    if(q && !(r.app+r.user+r.cap+r.model).toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });
  const totalCost = rows.reduce((s,r)=>s+r.cost,0);
  return <div className="stagger">
    <PageHead eyebrow="Control plane" title="Gateway Audit Log"
      sub="Every gateway call is recorded as (app, user, capability, outcome, cost). This is the platform's single source of truth for who did what."
      actions={<Button variant="ghost" icon="ext" size="md">Export</Button>}/>

    {/* filters */}
    <div style={{ display:'flex', gap:10, alignItems:'center', marginBottom:'var(--gap)', flexWrap:'wrap' }}>
      <div style={{ display:'flex', alignItems:'center', gap:9, height:38, padding:'0 12px', background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:9, flex:1, minWidth:220 }}>
        <Icon name="search" size={15} style={{ color:'var(--fg-3)' }}/>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Filter by app, user, capability, model…" style={{ flex:1, background:'none', border:'none', outline:'none', color:'var(--fg)', fontSize:13, fontFamily:'var(--font-mono)' }}/>
      </div>
      <Seg label="Outcome" value={out} setValue={setOut} options={[['all','All'],['ok','OK'],['blocked','Blocked'],['quota','Quota'],['denied','Denied']]}/>
      <Seg label="Capability" value={cap} setValue={setCap} options={[['all','All'],['llm','LLM'],['data','Data'],['mcp','MCP'],['fetch','Fetch']]}/>
    </div>

    <div style={{ display:'flex', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card style={{ flex:1, padding:'14px 18px' }}><Stat label="Events shown" value={rows.length} icon="list"/></Card>
      <Card style={{ flex:1, padding:'14px 18px' }}><Stat label="Tokens" value={fmt(rows.reduce((s,r)=>s+r.tok,0))} icon="cpu"/></Card>
      <Card style={{ flex:1, padding:'14px 18px' }}><Stat label="Cost" value={'$'+totalCost.toFixed(3)} icon="bolt"/></Card>
      <Card style={{ flex:1, padding:'14px 18px' }}><Stat label="Blocked / denied" value={rows.filter(r=>r.out==='blocked'||r.out==='denied').length} tone="var(--bad)" icon="shield"/></Card>
    </div>

    <div style={{ border:'1px solid var(--line)', borderRadius:'var(--r-lg)', overflow:'hidden', background:'var(--bg-1)' }}>
      <div style={{ display:'grid', gridTemplateColumns:'92px 150px 1fr 150px 110px 90px 80px', gap:10, padding:'11px 18px', borderBottom:'1px solid var(--line)', background:'var(--bg-2)' }} className="eyebrow">
        <span>Time</span><span>App</span><span>User</span><span>Capability</span><span>Model / target</span><span style={{ textAlign:'right' }}>Tokens</span><span style={{ textAlign:'right' }}>Outcome</span>
      </div>
      <div style={{ maxHeight:440, overflowY:'auto' }}>
        {rows.map((r,i)=>{ const [tone,label]=OUT[r.out]||OUT.ok; return (
          <div key={i} style={{ display:'grid', gridTemplateColumns:'92px 150px 1fr 150px 110px 90px 80px', gap:10, padding:'10px 18px',
            borderBottom:'1px solid var(--line)', alignItems:'center', fontFamily:'var(--font-mono)', fontSize:12 }}>
            <span style={{ color:'var(--fg-3)' }}>{r.t}</span>
            <span style={{ color:'var(--acc)' }}>{r.app}</span>
            <span style={{ color: r.user.startsWith('anon')?'var(--fg-4)':'var(--fg-2)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{r.user}</span>
            <span style={{ color:'var(--fg)' }}>{r.cap}</span>
            <span style={{ color:'var(--fg-3)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{r.model}</span>
            <span className="tnum" style={{ textAlign:'right', color:'var(--fg-2)' }}>{r.tok?r.tok.toLocaleString():'—'}</span>
            <span style={{ textAlign:'right' }}><Badge tone={tone} style={{ padding:'2px 7px', fontSize:10 }}>{label}</Badge></span>
          </div>
        );})}
        {rows.length===0 && <div style={{ padding:'40px', textAlign:'center', color:'var(--fg-3)', fontSize:13 }}>No events match these filters.</div>}
      </div>
    </div>
    <Hint icon="shield" tone="info" >The audit log is streamed to a write-only immutable sink, so the gateway's own DB credentials can't rewrite history.</Hint>
  </div>;
}
function Seg({ label, value, setValue, options }){
  return <div style={{ display:'inline-flex', alignItems:'center', gap:2, padding:3, background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:9 }}>
    {options.map(([id,l])=>{ const on=value===id; return (
      <button key={id} onClick={()=>setValue(id)} style={{ padding:'5px 10px', borderRadius:6, border:'none', cursor:'pointer',
        background: on?'var(--bg-4)':'transparent', color: on?'var(--fg)':'var(--fg-3)', fontFamily:'var(--font-ui)', fontSize:12, fontWeight:600 }}>{l}</button>
    );})}
  </div>;
}

// ---- Platform usage / cost -----------------------------------------
function AdminPlatform(){
  const t = PLATFORM.totals;
  return <div className="stagger">
    <PageHead eyebrow="Control plane" title="Platform" sub="Usage and cost across every hosted app. The gateway is the single choke point, so every number here is exact — not sampled telemetry."/>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card><Stat icon="grid" label="Apps" value={t.apps} sub={`${t.live} live`}/></Card>
      <Card><Stat icon="bolt" label="Requests MTD" value={t.requestsMTD}/></Card>
      <Card><Stat icon="cpu" label="Tokens MTD" value={t.tokensMTD}/></Card>
      <Card><Stat icon="key" label="Cost MTD" value={'$'+t.mtdCost.toFixed(0)} tone="var(--acc)"/></Card>
      <Card><Stat icon="user" label="Active users" value={t.activeUsers}/></Card>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div className="eyebrow">LLM tokens · 14 days (M)</div><Badge tone="acc" icon="arrowU">+38% wk</Badge>
        </div>
        <Bars data={PLATFORM.tokens14d} h={150} color="var(--info)"/>
      </Card>
      <Card>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div className="eyebrow">Gateway requests · 14 days (k)</div><Badge tone="acc" icon="arrowU">+24% wk</Badge>
        </div>
        <Bars data={PLATFORM.requests14d} h={150} color="var(--acc)"/>
      </Card>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'var(--gap)' }}>
      <Card>
        <div className="eyebrow" style={{ marginBottom:16 }}>Cost by app · month to date</div>
        {PLATFORM.costByApp.map(c=>(
          <div key={c.app} style={{ display:'flex', alignItems:'center', gap:14, padding:'9px 0' }}>
            <span style={{ fontSize:13, width:140, fontWeight:500 }}>{c.app}</span>
            <div style={{ flex:1 }}><Meter pct={c.pct*2.6} tone="var(--acc)"/></div>
            <span className="mono tnum" style={{ fontSize:13, width:64, textAlign:'right' }}>${c.cost.toFixed(2)}</span>
          </div>
        ))}
      </Card>
      <Card>
        <div className="eyebrow" style={{ marginBottom:16 }}>Capability mix · MTD</div>
        <div style={{ display:'flex', justifyContent:'center', padding:'8px 0 18px' }}><Donut segments={[['LLM',62,'var(--info)'],['Data',22,'var(--acc)'],['MCP',9,'var(--violet)'],['Fetch',7,'var(--warn)']]}/></div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 14px' }}>
          {[['LLM','62%','var(--info)'],['Data','22%','var(--acc)'],['MCP','9%','var(--violet)'],['Fetch','7%','var(--warn)']].map(([l,v,c])=>(
            <div key={l} style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ width:9, height:9, borderRadius:3, background:c }}/>
              <span style={{ fontSize:12.5, color:'var(--fg-2)', flex:1 }}>{l}</span>
              <span className="mono" style={{ fontSize:12.5, fontWeight:600 }}>{v}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  </div>;
}
function Donut({ segments }){
  const total = segments.reduce((s,x)=>s+x[1],0);
  let acc=0; const R=52, C=2*Math.PI*R;
  return <svg width="130" height="130" viewBox="0 0 130 130">
    <circle cx="65" cy="65" r={R} fill="none" stroke="var(--bg-3)" strokeWidth="16"/>
    {segments.map(([l,v,c],i)=>{ const len=(v/total)*C; const off=acc; acc+=len; return (
      <circle key={i} cx="65" cy="65" r={R} fill="none" stroke={c} strokeWidth="16"
        strokeDasharray={`${len} ${C-len}`} strokeDashoffset={-off} transform="rotate(-90 65 65)" strokeLinecap="butt"/>
    );})}
    <text x="65" y="61" textAnchor="middle" fontFamily="var(--font-mono)" fontSize="19" fontWeight="600" fill="var(--fg)">$486</text>
    <text x="65" y="78" textAnchor="middle" fontFamily="var(--font-mono)" fontSize="9" fill="var(--fg-3)" letterSpacing="1.5">MTD</text>
  </svg>;
}

// ---- All-apps registry ---------------------------------------------
function AdminRegistry({ go }){
  const [q,setQ] = useState('');
  const rows = APPS.filter(a=>(a.name+a.sub+a.owner+a.team).toLowerCase().includes(q.toLowerCase()));
  return <div className="stagger">
    <PageHead eyebrow="Control plane" title="All Apps" sub="The org-wide app registry — source of truth in Postgres. Lifecycle actions take effect at the gateway immediately."
      actions={<div style={{ display:'flex', alignItems:'center', gap:9, height:38, padding:'0 12px', background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:9, width:240 }}>
        <Icon name="search" size={15} style={{ color:'var(--fg-3)' }}/>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search registry…" style={{ flex:1, background:'none', border:'none', outline:'none', color:'var(--fg)', fontSize:13 }}/>
      </div>}/>
    <div style={{ border:'1px solid var(--line)', borderRadius:'var(--r-lg)', overflow:'hidden', background:'var(--bg-1)' }}>
      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 120px 130px 110px 90px 110px', gap:12, padding:'11px 18px', borderBottom:'1px solid var(--line)', background:'var(--bg-2)' }} className="eyebrow">
        <span>App</span><span>Visibility</span><span>Owner</span><span>Version</span><span>Status</span><span style={{ textAlign:'right' }}>Lifecycle</span>
      </div>
      {rows.map((a,i)=>(
        <div key={a.id} onClick={()=>go('app:'+a.id)} style={{ display:'grid', gridTemplateColumns:'1.4fr 120px 130px 110px 90px 110px', gap:12, padding:'13px 18px',
          borderBottom: i<rows.length-1?'1px solid var(--line)':'none', alignItems:'center', cursor:'pointer', transition:'background .12s' }}
          onMouseEnter={e=>e.currentTarget.style.background='var(--bg-2)'} onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
          <div style={{ display:'flex', alignItems:'center', gap:11, minWidth:0 }}>
            <div style={{ width:32, height:32, borderRadius:8, background:'var(--bg-3)', border:'1px solid var(--line-2)', display:'grid', placeItems:'center', flexShrink:0, fontSize:13, fontFamily:'var(--font-disp)', fontWeight:600, color:'var(--fg-2)' }}>{a.name[0]}</div>
            <div style={{ minWidth:0 }}><div style={{ fontSize:13.5, fontWeight:600 }}>{a.name}</div><div className="mono" style={{ fontSize:11, color:'var(--fg-3)' }}>{a.sub}.azx-labs.com</div></div>
          </div>
          <VisBadge v={a.visibility} group={a.group}/>
          <span style={{ fontSize:13, color:'var(--fg-2)' }}>{a.owner}</span>
          <span className="mono" style={{ fontSize:12.5, color:'var(--fg-2)' }}>{a.live||a.preview} {a.preview&&a.live?'·prev':''}</span>
          <div style={{ display:'flex', alignItems:'center', gap:7 }}><StatusDot kind={a.status==='live'?a.health:a.status} pulse={false} size={7}/><span style={{ fontSize:12, color:'var(--fg-3)' }}>{(STATUS[a.status==='live'?a.health:a.status]||STATUS.healthy).label}</span></div>
          <div style={{ textAlign:'right' }} onClick={e=>e.stopPropagation()}>
            {a.status==='disabled' ? <Button variant="ghost" size="sm" icon="rotate">Enable</Button>
              : <Button variant="danger" size="sm" icon="clock">Disable</Button>}
          </div>
        </div>
      ))}
    </div>
  </div>;
}

// ---- CSP violations -------------------------------------------------
function AdminViolations(){
  const [req,setReq] = useState({});
  return <div className="stagger">
    <PageHead eyebrow="Control plane" title="CSP Violations" sub="The proxy reports every blocked request. We turn them into plain-English, one-click capability fixes — silent breakage becomes a guided flow."
      actions={<Badge tone="bad" icon="shield" style={{ fontSize:11 }}>{VIOLATIONS.filter(v=>!v.requested&&!req[v.id]).length} unhandled</Badge>}/>
    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      {VIOLATIONS.map(v=>{ const handled = v.requested||req[v.id]; return (
        <Card key={v.id} style={{ display:'grid', gridTemplateColumns:'1fr auto', gap:20, alignItems:'center',
          borderColor: v.danger?'var(--bad-dim)':'var(--line)' }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:9, flexWrap:'wrap' }}>
              <Badge tone={v.danger?'bad':'warn'} icon={v.danger?'shield':'alert'}>{v.directive}</Badge>
              <span style={{ display:'flex', alignItems:'center', gap:6, fontSize:12.5, whiteSpace:'nowrap' }}><Icon name="box" size={13} style={{ color:'var(--fg-3)' }}/><span className="mono" style={{ color:'var(--acc)' }}>{v.app}</span></span>
              <span className="mono" style={{ fontSize:11.5, color:'var(--fg-3)', whiteSpace:'nowrap' }}>{v.count}× · last {v.last} ago</span>
            </div>
            <div style={{ fontSize:14, fontWeight:500, marginBottom:6 }}>{v.plain}</div>
            <code style={{ fontFamily:'var(--font-mono)', fontSize:12, color:'var(--fg-3)', background:'var(--bg-2)', padding:'4px 8px', borderRadius:6, border:'1px solid var(--line)', display:'inline-block' }}>blocked → {v.blocked}</code>
          </div>
          <div style={{ minWidth:170, display:'flex', justifyContent:'flex-end' }}>
            {v.danger ? <Button variant="danger" icon="x">Investigate</Button>
              : handled ? <Badge tone="violet" icon="check">Request filed</Badge>
              : <Button variant="primary" icon="plus" onClick={()=>setReq(r=>({...r,[v.id]:1}))}>Request this origin</Button>}
          </div>
        </Card>
      );})}
    </div>
    <Hint icon="shield" tone="info" >Granting an origin adds a <span className="mono">connect-src</span> exception — or route the call through the gateway <span className="mono">fetch-proxy</span> instead for auditing, metering, and server-side secrets.</Hint>
  </div>;
}

Object.assign(window, { AdminApprovals, AdminAudit, AdminPlatform, AdminRegistry, AdminViolations });
