// ============================================================
// AZX — Deploy flow. Two variations (tweak: deployFlow).
//   "wizard"  — guided right-side drawer, step by step
//   "command" — CLI-first centered modal (azx deploy + device code)
// Both honor the doc's preview→promote guardrail.
// ============================================================

function Overlay({ children, onClose, align='flex-end' }){
  return <div onClick={onClose} style={{ position:'fixed', inset:0, zIndex:60, background:'rgba(4,5,6,.62)',
    backdropFilter:'blur(3px)', display:'flex', justifyContent:align }}>
    <div onClick={e=>e.stopPropagation()} style={{ display:'contents' }}>{children}</div>
  </div>;
}

function DropZone({ done, onDrop }){
  const [over,setOver] = useState(false);
  return <div onClick={onDrop}
    onDragOver={e=>{e.preventDefault();setOver(true);}} onDragLeave={()=>setOver(false)}
    onDrop={e=>{e.preventDefault();setOver(false);onDrop();}}
    style={{ border:`1.5px dashed ${over?'var(--acc)':'var(--line-3)'}`, borderRadius:'var(--r-lg)',
      padding:'34px 24px', textAlign:'center', background:over?'var(--acc-dim)':'var(--bg-2)',
      transition:'all .16s', cursor:'pointer' }}>
    {done ? <>
      <div style={{ width:46, height:46, margin:'0 auto 12px', borderRadius:12, background:'var(--live-dim)',
        display:'grid', placeItems:'center', color:'var(--live)' }}><Icon name="box" size={22}/></div>
      <div style={{ fontWeight:600, fontSize:14 }}>dist.zip <span className="mono" style={{ color:'var(--fg-3)', fontWeight:400 }}>· 2.1 MB · 38 files</span></div>
      <div style={{ fontSize:12.5, color:'var(--fg-3)', marginTop:4 }}>Static bundle validated — click to replace</div>
    </> : <>
      <div style={{ width:46, height:46, margin:'0 auto 12px', borderRadius:12, background:'var(--bg-3)',
        display:'grid', placeItems:'center', color:'var(--fg-2)' }}><Icon name="upload" size={22}/></div>
      <div style={{ fontWeight:600, fontSize:14 }}>Drop your built bundle here</div>
      <div style={{ fontSize:12.5, color:'var(--fg-3)', marginTop:4 }}>A zip of <span className="mono">dist/</span> — static files only, ≤ 50 MB</div>
    </>}
  </div>;
}

// Validation / CSP courtesy-lint result rows
function LintRow({ tone, icon, title, detail, action }){
  const c = { ok:'var(--live)', warn:'var(--warn)', info:'var(--info)' }[tone];
  return <div style={{ display:'flex', gap:11, padding:'11px 0', borderBottom:'1px solid var(--line)' }}>
    <Icon name={icon} size={16} style={{ color:c, flexShrink:0, marginTop:1 }}/>
    <div style={{ flex:1, minWidth:0 }}>
      <div style={{ fontSize:13, fontWeight:600 }}>{title}</div>
      {detail && <div style={{ fontSize:12.5, color:'var(--fg-3)', marginTop:2 }}>{detail}</div>}
    </div>
    {action}
  </div>;
}

const STEPS = [
  { id:'source', label:'Source' },
  { id:'validate', label:'Validate' },
  { id:'preview', label:'Preview' },
  { id:'promote', label:'Promote' },
];

// ---- VARIANT: wizard (drawer) --------------------------------------
function WizardDeploy({ onClose }){
  const [step,setStep] = useState(0);
  const [dropped,setDropped] = useState(false);
  const [promoted,setPromoted] = useState(false);
  const next = ()=> setStep(s=>Math.min(s+1,3));
  const canNext = step!==0 || dropped;

  return <Overlay onClose={onClose}>
    <div style={{ width:520, maxWidth:'94vw', height:'100vh', background:'var(--bg-1)', borderLeft:'1px solid var(--line-2)',
      boxShadow:'-30px 0 80px -40px #000', display:'flex', flexDirection:'column', animation:'az-drawer .26s cubic-bezier(.2,.7,.3,1)' }}>
      {/* header */}
      <div style={{ padding:'20px 24px', borderBottom:'1px solid var(--line)' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <Icon name="upload" size={18} style={{ color:'var(--acc)' }}/>
            <h3 style={{ fontSize:16 }}>Deploy to <span className="mono" style={{ color:'var(--acc)' }}>cost-explorer</span></h3>
          </div>
          <Button variant="subtle" icon="x" size="sm" onClick={onClose}/>
        </div>
        {/* stepper */}
        <div style={{ display:'flex', alignItems:'center', gap:0, marginTop:18 }}>
          {STEPS.map((s,i)=>(
            <React.Fragment key={s.id}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:24, height:24, borderRadius:'50%', display:'grid', placeItems:'center', fontSize:11.5,
                  fontFamily:'var(--font-mono)', fontWeight:600, transition:'all .2s',
                  background: i<step?'var(--acc)':i===step?'var(--acc-dim)':'var(--bg-3)',
                  color: i<step?'var(--acc-ink)':i===step?'var(--acc)':'var(--fg-3)',
                  border:`1px solid ${i<=step?'var(--acc-line)':'var(--line-2)'}` }}>
                  {i<step?<Icon name="check" size={13}/>:i+1}
                </div>
                <span style={{ fontSize:12.5, fontWeight: i===step?600:500, color: i<=step?'var(--fg)':'var(--fg-3)' }}>{s.label}</span>
              </div>
              {i<STEPS.length-1 && <div style={{ flex:1, height:1, background: i<step?'var(--acc-line)':'var(--line-2)', margin:'0 10px' }}/>}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* body */}
      <div style={{ flex:1, overflowY:'auto', padding:'22px 24px' }}>
        {step===0 && <div className="stagger" style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom:10 }}>How are you shipping?</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Card pad style={{ padding:14, borderColor:'var(--acc-line)', background:'var(--acc-dim)' }}>
                <Icon name="upload" size={18} style={{ color:'var(--acc)' }}/>
                <div style={{ fontWeight:600, fontSize:13.5, marginTop:8 }}>Portal upload</div>
                <div style={{ fontSize:12, color:'var(--fg-3)', marginTop:3 }}>Drop a built bundle right here.</div>
              </Card>
              <Card pad style={{ padding:14 }}>
                <Icon name="terminal" size={18} style={{ color:'var(--fg-2)' }}/>
                <div style={{ fontWeight:600, fontSize:13.5, marginTop:8 }}>CLI / agent</div>
                <div className="mono" style={{ fontSize:11.5, color:'var(--fg-3)', marginTop:3 }}>azx deploy</div>
              </Card>
            </div>
          </div>
          <DropZone done={dropped} onDrop={()=>setDropped(true)}/>
          <Hint icon="shield" tone="info">Bundles deploy as <b>immutable versions</b>. “Deploy” just flips a pointer — rollback flips it back.</Hint>
        </div>}

        {step===1 && <div className="stagger">
          <div className="eyebrow" style={{ marginBottom:6 }}>Artifact validation</div>
          <LintRow tone="ok" icon="check" title="Static files only" detail="38 files · no server-side code detected"/>
          <LintRow tone="ok" icon="check" title="Size & type sanity" detail="2.1 MB — within the 50 MB limit"/>
          <div className="eyebrow" style={{ margin:'18px 0 6px' }}>CSP courtesy lint <span style={{ color:'var(--fg-4)' }}>· warnings, not gates</span></div>
          <LintRow tone="warn" icon="alert" title="References api.exchangerate.host"
            detail="connect-src will block this until the origin is granted."
            action={<Button variant="ghost" size="sm">Request</Button>}/>
          <LintRow tone="info" icon="bolt" title="Inline scripts & CDN tags — allowed"
            detail="Code-provenance is relaxed by design; data flow is the boundary."/>
          <Hint icon="shield" tone="info" >Linting never blocks a deploy. Blocked calls surface as click-to-fix violation reports after you ship.</Hint>
        </div>}

        {step===2 && <div className="stagger" style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Card style={{ background:'var(--violet-dim)', borderColor:'color-mix(in srgb,var(--violet) 30%,transparent)' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <StatusDot kind="preview" pulse={false}/>
              <div style={{ fontWeight:600 }}>Preview deployed — <span className="mono">v25</span></div>
            </div>
            <a style={{ display:'flex', alignItems:'center', gap:7, marginTop:12, color:'var(--violet)', fontSize:13, fontFamily:'var(--font-mono)' }}>
              cost-explorer--v25.preview.azx-labs.com <Icon name="ext" size={13}/>
            </a>
            <div style={{ fontSize:12.5, color:'var(--fg-2)', marginTop:10, lineHeight:1.5 }}>
              Live traffic still serves <b className="mono" style={{ color:'var(--fg)' }}>v24</b>. Agent deploys land on preview by default —
              promoting to live takes a deliberate human action.
            </div>
          </Card>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <KV k="Bundle" mono>2.1 MB · 38</KV><KV k="Build sha" mono>b3f9a1c</KV>
            <KV k="Deployed by" mono>kyle</KV><KV k="Via" mono>portal</KV>
          </div>
        </div>}

        {step===3 && <div className="stagger" style={{ display:'flex', flexDirection:'column', gap:18, alignItems:'center', textAlign:'center', paddingTop:18 }}>
          <div style={{ width:64, height:64, borderRadius:18, background: promoted?'var(--live-dim)':'var(--acc-dim)',
            display:'grid', placeItems:'center', color: promoted?'var(--live)':'var(--acc)', transition:'all .3s' }}>
            <Icon name={promoted?'check':'arrowU'} size={30}/>
          </div>
          {promoted ? <>
            <div>
              <h3 style={{ fontSize:18 }}>v25 is live</h3>
              <p style={{ color:'var(--fg-3)', fontSize:13.5, marginTop:6 }}>Serving at <span className="mono" style={{ color:'var(--acc)' }}>cost-explorer.azx-labs.com</span>. The previous version is one click away.</p>
            </div>
            <Badge tone="live" icon="dot">Pointer flipped · v24 → v25</Badge>
          </> : <>
            <div>
              <h3 style={{ fontSize:18 }}>Promote v25 to live?</h3>
              <p style={{ color:'var(--fg-3)', fontSize:13.5, marginTop:6, maxWidth:360 }}>This flips the registry pointer so all users get v25. Production gets one click of supervision.</p>
            </div>
          </>}
        </div>}
      </div>

      {/* footer */}
      <div style={{ padding:'16px 24px', borderTop:'1px solid var(--line)', display:'flex', justifyContent:'space-between', alignItems:'center', gap:12 }}>
        <Button variant="subtle" size="md" onClick={step===0?onClose:()=>setStep(s=>s-1)}>{step===0?'Cancel':'Back'}</Button>
        {step<3 ? <Button variant="primary" iconR="chevR" disabled={!canNext} onClick={next}>
          {step===0?'Validate':step===1?'Deploy preview':'Continue'}
        </Button> : promoted
          ? <Button variant="primary" icon="check" onClick={onClose}>Done</Button>
          : <Button variant="primary" icon="arrowU" onClick={()=>setPromoted(true)}>Promote to live</Button>}
      </div>
    </div>
  </Overlay>;
}

// ---- VARIANT: command (CLI-first modal) ----------------------------
function CommandDeploy({ onClose }){
  const [authed,setAuthed] = useState(false);
  const [deployed,setDeployed] = useState(false);
  const [promoted,setPromoted] = useState(false);
  return <Overlay onClose={onClose} align="center">
    <div style={{ width:560, maxWidth:'94vw', alignSelf:'center', background:'var(--bg-1)', border:'1px solid var(--line-2)',
      borderRadius:'var(--r-xl)', boxShadow:'0 40px 120px -40px #000', animation:'az-pop .24s cubic-bezier(.2,.7,.3,1)', overflow:'hidden' }}>
      <div style={{ padding:'20px 24px', borderBottom:'1px solid var(--line)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Icon name="terminal" size={18} style={{ color:'var(--acc)' }}/>
          <h3 style={{ fontSize:16 }}>Deploy <span className="mono" style={{ color:'var(--acc)' }}>cost-explorer</span></h3>
        </div>
        <Button variant="subtle" icon="x" size="sm" onClick={onClose}/>
      </div>

      <div style={{ padding:'22px 24px', display:'flex', flexDirection:'column', gap:16 }}>
        {/* terminal */}
        <div style={{ background:'#06070a', border:'1px solid var(--line)', borderRadius:'var(--r-md)', overflow:'hidden', fontFamily:'var(--font-mono)', fontSize:12.5 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 12px', borderBottom:'1px solid var(--line)', background:'var(--bg-1)' }}>
            <span style={{ width:9, height:9, borderRadius:'50%', background:'#ff5f57' }}/>
            <span style={{ width:9, height:9, borderRadius:'50%', background:'#febc2e' }}/>
            <span style={{ width:9, height:9, borderRadius:'50%', background:'#28c840' }}/>
            <span style={{ marginLeft:8, color:'var(--fg-4)', fontSize:11 }}>~/cost-explorer</span>
          </div>
          <div style={{ padding:'14px 14px', lineHeight:1.8, color:'var(--fg-2)' }}>
            <div><span style={{ color:'var(--acc)' }}>$</span> azx deploy ./dist</div>
            {!authed && <div style={{ color:'var(--warn)' }}>→ no cached token · starting Entra device-code auth…</div>}
            {authed && <>
              <div style={{ color:'var(--live)' }}>✓ authenticated as kyle@azx.io · token cached to keychain</div>
              <div>↑ uploading bundle … <span style={{ color:'var(--fg-4)' }}>2.1 MB · 38 files</span></div>
              {deployed && <>
                <div style={{ color:'var(--live)' }}>✓ validated · CSP lint: 1 warning (api.exchangerate.host)</div>
                <div style={{ color:'var(--violet)' }}>✓ preview v25 → cost-explorer--v25.preview.azx-labs.com</div>
                <div style={{ color:'var(--fg-4)' }}>  promote with one click in the portal ↓</div>
              </>}
            </>}
            <div style={{ display:'inline-block', width:7, height:15, background:'var(--acc)', verticalAlign:'middle', animation:'az-pulse 1s steps(1) infinite' }}/>
          </div>
        </div>

        {!authed && <>
          <div style={{ display:'flex', alignItems:'center', gap:14, padding:'14px 16px', background:'var(--bg-2)', border:'1px solid var(--line-2)', borderRadius:'var(--r-md)' }}>
            <Icon name="key" size={20} style={{ color:'var(--warn)' }}/>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:600 }}>Enter code at <span className="mono" style={{ color:'var(--acc)' }}>microsoft.com/devicelogin</span></div>
              <div className="mono" style={{ fontSize:20, letterSpacing:'.22em', marginTop:4, color:'var(--fg)' }}>FXJ7-QK2D</div>
            </div>
          </div>
          <Hint icon="shield" tone="info">The deploy skill ships <b>no credentials</b>. A short-lived, per-user × per-app token is cached in your OS keychain — never in the repo or agent context.</Hint>
          <Button variant="primary" icon="check" style={{ width:'100%' }} onClick={()=>{setAuthed(true);setTimeout(()=>setDeployed(true),500);}}>I’ve entered the code</Button>
        </>}

        {authed && !promoted && <>
          <Card style={{ background:'var(--violet-dim)', borderColor:'color-mix(in srgb,var(--violet) 30%,transparent)', opacity:deployed?1:.5, transition:'opacity .3s' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <StatusDot kind="preview" pulse={false}/>
                <span style={{ fontWeight:600 }}>Preview v25</span>
              </div>
              <Badge tone="violet">awaiting promote</Badge>
            </div>
            <div style={{ fontSize:12.5, color:'var(--fg-2)', marginTop:10, lineHeight:1.5 }}>Live still serves <b className="mono" style={{ color:'var(--fg)' }}>v24</b>. Agents iterate at full speed; production takes a human action.</div>
          </Card>
          <Button variant="primary" icon="arrowU" disabled={!deployed} style={{ width:'100%' }} onClick={()=>setPromoted(true)}>Promote v25 to live</Button>
        </>}

        {promoted && <div style={{ textAlign:'center', padding:'10px 0 6px', animation:'az-rise .3s' }}>
          <div style={{ width:56, height:56, borderRadius:16, background:'var(--live-dim)', display:'grid', placeItems:'center', color:'var(--live)', margin:'0 auto 14px' }}><Icon name="check" size={26}/></div>
          <h3 style={{ fontSize:17 }}>v25 is live</h3>
          <p style={{ color:'var(--fg-3)', fontSize:13, marginTop:6 }}>Serving at <span className="mono" style={{ color:'var(--acc)' }}>cost-explorer.azx-labs.com</span></p>
          <Button variant="primary" icon="check" style={{ marginTop:16 }} onClick={onClose}>Done</Button>
        </div>}
      </div>
    </div>
  </Overlay>;
}

function DeployFlow({ variant, onClose }){
  return variant==='command' ? <CommandDeploy onClose={onClose}/> : <WizardDeploy onClose={onClose}/>;
}

Object.assign(window, { DeployFlow });
