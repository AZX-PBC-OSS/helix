// ============================================================
// AZX — app shell. Two nav variants (sidebar / topnav) chosen via tweak.
// One portal; a role switch reveals admin sections.
// ============================================================

const OWNER_NAV = [
  { id:'apps',     label:'My Apps',     icon:'grid' },
  { id:'usage',    label:'Usage',       icon:'gauge' },
];
const ADMIN_NAV = [
  { id:'approvals',  label:'Approvals',   icon:'check' },
  { id:'audit',      label:'Audit Log',   icon:'list' },
  { id:'platform',   label:'Platform',    icon:'activity' },
  { id:'registry',   label:'All Apps',    icon:'layers' },
  { id:'violations', label:'Violations',  icon:'shield' },
];

function Brand({ small }){
  return <div style={{ display:'flex', alignItems:'center', gap:10 }}>
    <div style={{ width:small?26:30, height:small?26:30, borderRadius:8, background:'var(--acc)',
      display:'grid', placeItems:'center', flexShrink:0, position:'relative', overflow:'hidden',
      boxShadow:'0 0 22px -6px var(--acc-line)' }}>
      <span style={{ fontFamily:'var(--font-disp)', fontWeight:700, fontSize:small?13:15, color:'var(--acc-ink)', letterSpacing:'-.04em' }}>az</span>
    </div>
    <div style={{ lineHeight:1 }}>
      <div style={{ fontFamily:'var(--font-disp)', fontWeight:700, fontSize:small?15:16, letterSpacing:'-.02em' }}>AZX</div>
      <div className="mono" style={{ fontSize:9, color:'var(--fg-3)', letterSpacing:'.16em', marginTop:2 }}>CONTROL PLANE</div>
    </div>
  </div>;
}

// Role switch — segmented
function RoleSwitch({ role, setRole, compact }){
  return <div style={{ display:'inline-flex', padding:3, background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:9, gap:2 }}>
    {[['owner','Owner','user'],['admin','Admin','shield']].map(([id,label,ic])=>{
      const on = role===id;
      return <button key={id} onClick={()=>setRole(id)} style={{ display:'inline-flex', alignItems:'center', gap:6,
        padding: compact?'5px 9px':'6px 12px', borderRadius:6, border:'none', cursor:'pointer',
        background:on?(id==='admin'?'var(--violet-dim)':'var(--acc-dim)'):'transparent',
        color:on?(id==='admin'?'var(--violet)':'var(--acc)'):'var(--fg-3)',
        fontFamily:'var(--font-ui)', fontSize:12.5, fontWeight:600, transition:'all .14s' }}>
        <Icon name={ic} size={14}/>{label}
      </button>;
    })}
  </div>;
}

function NavItem({ item, active, onClick, horizontal }){
  const [h,setH] = useState(false);
  const on = active;
  if(horizontal){
    return <button onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
      style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'8px 13px', borderRadius:8, border:'none',
        background:on?'rgba(255,255,255,.06)':'transparent', color:on?'var(--fg)':(h?'var(--fg-2)':'var(--fg-3)'),
        fontFamily:'var(--font-ui)', fontSize:13.5, fontWeight:on?600:500, cursor:'pointer', transition:'all .14s', position:'relative' }}>
      <Icon name={item.icon} size={16} style={{ color:on?'var(--acc)':'inherit' }}/>{item.label}
      {item.badge!=null && <span className="mono" style={{ fontSize:10.5, color:on?'var(--acc)':'var(--fg-4)' }}>{item.badge}</span>}
    </button>;
  }
  return <button onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{ display:'flex', alignItems:'center', gap:11, width:'100%', padding:'9px 11px', borderRadius:9, border:'none',
      background:on?'rgba(255,255,255,.055)':'transparent', color:on?'var(--fg)':(h?'var(--fg-2)':'var(--fg-3)'),
      fontFamily:'var(--font-ui)', fontSize:13.5, fontWeight:on?600:500, cursor:'pointer', transition:'all .14s', position:'relative', textAlign:'left' }}>
    {on && <span style={{ position:'absolute', left:-9, top:'50%', transform:'translateY(-50%)', width:3, height:18, background:'var(--acc)', borderRadius:3 }}/>}
    <Icon name={item.icon} size={17} style={{ color:on?'var(--acc)':'inherit', flexShrink:0 }}/>
    <span style={{ flex:1 }}>{item.label}</span>
    {item.badge!=null && <span className="mono" style={{ fontSize:11, fontWeight:600,
      color:on?'var(--acc)':'var(--fg-4)', background:on?'var(--acc-dim)':'transparent', borderRadius:20, padding:'1px 7px' }}>{item.badge}</span>}
  </button>;
}

function UserChip({ compact }){
  return <div style={{ display:'flex', alignItems:'center', gap:10, padding: compact?'0':'10px 8px', borderRadius:10 }}>
    <div style={{ width:30, height:30, borderRadius:'50%', background:'linear-gradient(135deg,#2b3138,#171b1f)',
      border:'1px solid var(--line-2)', display:'grid', placeItems:'center', flexShrink:0,
      fontFamily:'var(--font-disp)', fontWeight:600, fontSize:12, color:'var(--fg-2)' }}>KR</div>
    {!compact && <div style={{ lineHeight:1.25, minWidth:0 }}>
      <div style={{ fontSize:13, fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>Kyle R.</div>
      <div className="mono" style={{ fontSize:10.5, color:'var(--fg-3)' }}>kyle@azx.io</div>
    </div>}
  </div>;
}

// fake command/search bar
function CommandBar({ wide }){
  const [f,setF] = useState(false);
  return <div style={{ display:'flex', alignItems:'center', gap:9, height:36, padding:'0 12px',
    background:'var(--bg-2)', border:`1px solid ${f?'var(--line-3)':'var(--line)'}`, borderRadius:9,
    width: wide?340:260, transition:'border-color .14s', cursor:'text' }}
    onFocus={()=>setF(true)} onBlur={()=>setF(false)}>
    <Icon name="search" size={15} style={{ color:'var(--fg-3)' }}/>
    <input placeholder="Search apps, audit, users…" style={{ flex:1, background:'none', border:'none', outline:'none',
      color:'var(--fg)', fontSize:13, fontFamily:'var(--font-ui)' }}/>
    <kbd className="mono" style={{ fontSize:10.5, color:'var(--fg-4)', border:'1px solid var(--line-2)', borderRadius:5, padding:'1px 5px' }}>⌘K</kbd>
  </div>;
}

// ---- SIDEBAR shell --------------------------------------------------
function SidebarShell({ role, setRole, nav, current, go, children, ownerCounts, adminCounts }){
  const ownerItems = OWNER_NAV.map(n=>({ ...n, badge: ownerCounts[n.id] }));
  const adminItems = ADMIN_NAV.map(n=>({ ...n, badge: adminCounts[n.id] }));
  return <div style={{ display:'flex', height:'100vh', position:'relative', zIndex:1 }}>
    <aside style={{ width:'var(--sb-w)', flexShrink:0, borderRight:'1px solid var(--line)', background:'var(--bg-1)',
      display:'flex', flexDirection:'column', padding:'18px 14px' }}>
      <div style={{ padding:'4px 6px 18px' }}><Brand/></div>
      <Button variant="primary" icon="upload" size="md" style={{ width:'100%', marginBottom:18 }}
        onClick={()=>go('apps','__deploy')}>Deploy app</Button>

      <div className="eyebrow" style={{ padding:'0 8px 8px' }}>Workspace</div>
      <nav style={{ display:'flex', flexDirection:'column', gap:2 }}>
        {ownerItems.map(it=><NavItem key={it.id} item={it} active={current===it.id} onClick={()=>go(it.id)}/>)}
      </nav>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'18px 8px 8px' }}>
        <span className="eyebrow">Admin</span>
        <Badge tone="violet" mono style={{ padding:'2px 6px', fontSize:9.5 }}>ELEVATED</Badge>
      </div>
      <nav style={{ display:'flex', flexDirection:'column', gap:2, opacity: role==='admin'?1:.45,
        pointerEvents: role==='admin'?'auto':'none', transition:'opacity .2s' }}>
        {adminItems.map(it=><NavItem key={it.id} item={it} active={current===it.id} onClick={()=>go(it.id)}/>)}
      </nav>

      <div style={{ flex:1 }}/>
      <div style={{ borderTop:'1px solid var(--line)', paddingTop:14, display:'flex', flexDirection:'column', gap:12 }}>
        <RoleSwitch role={role} setRole={setRole}/>
        <UserChip/>
      </div>
    </aside>

    <div style={{ flex:1, display:'flex', flexDirection:'column', minWidth:0 }}>
      <header style={{ height:62, flexShrink:0, borderBottom:'1px solid var(--line)', display:'flex',
        alignItems:'center', justifyContent:'space-between', padding:'0 28px', background:'rgba(8,9,11,.7)', backdropFilter:'blur(8px)' }}>
        <CommandBar wide/>
        <div style={{ display:'flex', alignItems:'center', gap:14 }}>
          <Badge tone="live" icon="dot">All systems normal</Badge>
          <span style={{ width:1, height:22, background:'var(--line-2)' }}/>
          <Button variant="subtle" icon="terminal" size="sm">CLI</Button>
        </div>
      </header>
      <main style={{ flex:1, overflowY:'auto', padding:'30px 28px 60px' }}>
        <div style={{ maxWidth:1180, margin:'0 auto' }}>{children}</div>
      </main>
    </div>
  </div>;
}

// ---- TOPNAV shell ---------------------------------------------------
function TopnavShell({ role, setRole, nav, current, go, children, ownerCounts, adminCounts }){
  const ownerItems = OWNER_NAV.map(n=>({ ...n, badge: ownerCounts[n.id] }));
  const adminItems = ADMIN_NAV.map(n=>({ ...n, badge: adminCounts[n.id] }));
  return <div style={{ display:'flex', flexDirection:'column', height:'100vh', position:'relative', zIndex:1 }}>
    <header style={{ flexShrink:0, borderBottom:'1px solid var(--line)', background:'rgba(8,9,11,.72)', backdropFilter:'blur(10px)' }}>
      <div style={{ height:60, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 26px', gap:20 }}>
        <div style={{ display:'flex', alignItems:'center', gap:24 }}>
          <Brand/>
          <span style={{ width:1, height:26, background:'var(--line-2)' }}/>
          <nav style={{ display:'flex', gap:3 }}>
            {ownerItems.map(it=><NavItem key={it.id} item={it} active={current===it.id} onClick={()=>go(it.id)} horizontal/>)}
            {role==='admin' && <>
              <span style={{ width:1, height:18, background:'var(--line-2)', alignSelf:'center', margin:'0 5px' }}/>
              {adminItems.map(it=><NavItem key={it.id} item={it} active={current===it.id} onClick={()=>go(it.id)} horizontal/>)}
            </>}
          </nav>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:14 }}>
          <CommandBar/>
          <RoleSwitch role={role} setRole={setRole} compact/>
          <Button variant="primary" icon="upload" size="sm" onClick={()=>go('apps','__deploy')}>Deploy</Button>
          <span style={{ width:1, height:22, background:'var(--line-2)' }}/>
          <UserChip compact/>
        </div>
      </div>
    </header>
    <main style={{ flex:1, overflowY:'auto', padding:'30px 26px 60px' }}>
      <div style={{ maxWidth:1180, margin:'0 auto' }}>{children}</div>
    </main>
  </div>;
}

Object.assign(window, { SidebarShell, TopnavShell, OWNER_NAV, ADMIN_NAV, Brand, RoleSwitch });
