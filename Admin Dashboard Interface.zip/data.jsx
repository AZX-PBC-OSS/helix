// ============================================================
// AZX — mock data. Vocabulary straight from the architecture doc:
// subdomains, visibility tiers, capability manifests, gateway audit,
// preview→promote, CSP violations, elevated-grant approvals.
// ============================================================

// ---- Apps (the org is "customer #0") --------------------------------
const APPS = [
  {
    id:'cost-explorer', name:'Cost Explorer', sub:'cost-explorer',
    desc:'Azure billing breakdowns with an LLM Q&A panel.',
    visibility:'private', owner:'Kyle R.', team:'Platform',
    status:'live', live:'v24', preview:null, health:'healthy',
    deployedBy:'kyle', deployedAgo:'2h', created:'Apr 2026',
    caps:{ llm:{models:['gpt-5','claude-fable-5'], tokens:2_000_000}, data:{app:true,user:true}, mcp:['azure-billing'], origins:[] },
    use:{ reqDay:14200, tokDay:1_340_000, tokBudget:2_000_000, storage:'412 MB', users7d:38, errRate:0.4 },
    spark:[8,11,9,14,12,18,15,22,19,24,21,28,26,31,29,34],
    flags:[],
  },
  {
    id:'standup-bot', name:'Standup Bot', sub:'standup',
    desc:'Async standup collection + daily digest for eng.',
    visibility:'group', group:'eng-team', owner:'Dana L.', team:'Engineering',
    status:'live', live:'v9', preview:'v10', health:'healthy',
    deployedBy:'dana', deployedAgo:'1d', created:'Apr 2026',
    caps:{ llm:{models:['gpt-5'], tokens:500_000}, data:{app:true,user:true}, mcp:[], origins:[] },
    use:{ reqDay:3100, tokDay:210_000, tokBudget:500_000, storage:'88 MB', users7d:24, errRate:0.1 },
    spark:[20,18,22,19,24,21,20,23,19,22,25,21,24,22,26,23],
    flags:['preview'],
  },
  {
    id:'design-critique', name:'Design Critique', sub:'critique',
    desc:'Drop a mock, get structured multi-model feedback.',
    visibility:'private', owner:'Mara S.', team:'Design',
    status:'live', live:'v17', preview:null, health:'degraded',
    deployedBy:'mara', deployedAgo:'5h', created:'May 2026',
    caps:{ llm:{models:['gpt-5','claude-fable-5'], tokens:3_000_000}, data:{app:true,user:false}, mcp:[], origins:['fonts.cdnfonts.com'] },
    use:{ reqDay:9800, tokDay:2_910_000, tokBudget:3_000_000, storage:'1.2 GB', users7d:31, errRate:2.3 },
    spark:[12,16,14,22,28,24,33,29,40,36,44,41,48,52,49,55],
    flags:['quota-near'],
  },
  {
    id:'release-notes', name:'Release Notes', sub:'release-notes',
    desc:'Turns merged PRs into customer-ready changelog drafts.',
    visibility:'private', owner:'Kyle R.', team:'Platform',
    status:'live', live:'v6', preview:null, health:'healthy',
    deployedBy:'ci', deployedAgo:'3d', created:'May 2026',
    caps:{ llm:{models:['claude-fable-5'], tokens:800_000}, data:{app:true,user:false}, mcp:['github-readonly'], origins:[] },
    use:{ reqDay:540, tokDay:96_000, tokBudget:800_000, storage:'34 MB', users7d:9, errRate:0.0 },
    spark:[4,6,5,7,6,8,5,9,7,6,8,7,9,8,10,9],
    flags:[],
  },
  {
    id:'customer-demo', name:'Customer Demo', sub:'demo-acme',
    desc:'Sandboxed demo build shared with ACME, password-gated.',
    visibility:'password', owner:'Priya N.', team:'Sales Eng',
    status:'live', live:'v3', preview:null, health:'healthy',
    deployedBy:'priya', deployedAgo:'6h', created:'Jun 2026',
    caps:{ llm:{models:['gpt-5'], tokens:250_000}, data:{app:false,user:false}, mcp:[], origins:[] },
    use:{ reqDay:1900, tokDay:54_000, tokBudget:250_000, storage:'12 MB', users7d:14, errRate:0.6 },
    spark:[2,5,9,14,11,18,22,16,24,19,12,8,15,21,17,23],
    flags:[],
  },
  {
    id:'status-page', name:'Status Page', sub:'status',
    desc:'Public incident + uptime board for the apps platform.',
    visibility:'public', owner:'Dana L.', team:'Engineering',
    status:'live', live:'v11', preview:null, health:'healthy',
    deployedBy:'dana', deployedAgo:'12h', created:'Jun 2026',
    caps:{ llm:{models:[], tokens:0}, data:{app:true,user:false}, mcp:[], origins:[] },
    use:{ reqDay:48200, tokDay:0, tokBudget:0, storage:'6 MB', users7d:0, errRate:0.2 },
    spark:[30,42,38,55,49,61,58,72,66,80,74,88,82,95,90,102],
    flags:['public'],
  },
  {
    id:'incident-timeline', name:'Incident Timeline', sub:'incidents',
    desc:'Stitches alerts + chat into a postmortem timeline.',
    visibility:'group', group:'sre', owner:'Theo K.', team:'SRE',
    status:'preview', live:null, preview:'v1', health:'healthy',
    deployedBy:'theo (agent)', deployedAgo:'22m', created:'Jun 2026',
    caps:{ llm:{models:['gpt-5'], tokens:600_000}, data:{app:true,user:true}, mcp:['pagerduty'], origins:['api.statuspage.io'] },
    use:{ reqDay:0, tokDay:0, tokBudget:600_000, storage:'0 MB', users7d:0, errRate:0.0 },
    spark:[0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
    flags:['preview','awaiting-promote'],
  },
  {
    id:'prompt-library', name:'Prompt Library', sub:'prompts',
    desc:'Shared, versioned prompt snippets for the design org.',
    visibility:'group', group:'design', owner:'Mara S.', team:'Design',
    status:'disabled', live:'v8', preview:null, health:'disabled',
    deployedBy:'mara', deployedAgo:'9d', created:'Apr 2026',
    caps:{ llm:{models:['gpt-5'], tokens:400_000}, data:{app:true,user:true}, mcp:[], origins:[] },
    use:{ reqDay:0, tokDay:0, tokBudget:400_000, storage:'140 MB', users7d:0, errRate:0.0 },
    spark:[14,12,15,11,9,7,5,3,2,1,0,0,0,0,0,0],
    flags:['disabled'],
  },
];

// ---- Versions / deploy history (per app) ----------------------------
const VERSIONS = {
  'cost-explorer':[
    { v:'v24', state:'live',     by:'kyle',         via:'cli',    ago:'2h',  size:'2.1 MB', files:38, note:'Add YoY comparison chart', sha:'a91f3c2' },
    { v:'v23', state:'previous', by:'kyle',         via:'cli',    ago:'1d',  size:'2.0 MB', files:37, note:'Fix tooltip overflow',      sha:'77be0d1' },
    { v:'v22', state:'archived', by:'ci',           via:'ci',     ago:'4d',  size:'2.0 MB', files:37, note:'Bump deps',                 sha:'1c4ae90' },
    { v:'v21', state:'archived', by:'kyle (agent)', via:'agent',  ago:'6d',  size:'1.9 MB', files:35, note:'Refactor data layer',       sha:'e02d5fb' },
    { v:'v20', state:'archived', by:'kyle',         via:'portal', ago:'8d',  size:'1.9 MB', files:35, note:'Initial billing MCP wire',  sha:'b8810a4' },
  ],
};
function versionsFor(id){
  if(VERSIONS[id]) return VERSIONS[id];
  return [
    { v:'v3', state:'live',     by:'owner', via:'cli',   ago:'6h', size:'880 KB', files:21, note:'Polish empty states', sha:'3fa1b9c' },
    { v:'v2', state:'previous', by:'owner', via:'agent', ago:'2d', size:'860 KB', files:21, note:'Add export button',   sha:'9d20c70' },
    { v:'v1', state:'archived', by:'owner', via:'portal',ago:'5d', size:'840 KB', files:20, note:'First deploy',        sha:'0aa4e15' },
  ];
}

// ---- Gateway audit log: (app, user, capability, outcome, cost) ------
const AUDIT = [
  { t:'14:32:08', app:'design-critique',   user:'mara@azx.io',     cap:'llm.chat',     model:'claude-fable-5', out:'ok',      tok:8400, cost:0.084 },
  { t:'14:32:01', app:'cost-explorer',     user:'kyle@azx.io',     cap:'mcp.azure-billing', model:'—',        out:'ok',      tok:0,    cost:0.002 },
  { t:'14:31:54', app:'design-critique',   user:'mara@azx.io',     cap:'llm.chat',     model:'gpt-5',          out:'quota',   tok:0,    cost:0 },
  { t:'14:31:40', app:'standup',           user:'dana@azx.io',     cap:'data.write',   model:'—',              out:'ok',      tok:0,    cost:0 },
  { t:'14:31:22', app:'demo-acme',         user:'anon·a91f',       cap:'llm.chat',     model:'gpt-5',          out:'ok',      tok:1200, cost:0.012 },
  { t:'14:31:09', app:'incidents',         user:'theo@azx.io',     cap:'fetch',        model:'api.statuspage.io', out:'blocked', tok:0, cost:0 },
  { t:'14:30:58', app:'cost-explorer',     user:'kyle@azx.io',     cap:'llm.chat',     model:'gpt-5',          out:'ok',      tok:5600, cost:0.056 },
  { t:'14:30:41', app:'status',            user:'anon',            cap:'data.read',    model:'—',              out:'ok',      tok:0,    cost:0 },
  { t:'14:30:33', app:'design-critique',   user:'mara@azx.io',     cap:'fetch',        model:'fonts.cdnfonts.com', out:'ok',  tok:0,    cost:0.001 },
  { t:'14:30:12', app:'standup',           user:'sam@azx.io',      cap:'llm.chat',     model:'gpt-5',          out:'ok',      tok:3200, cost:0.032 },
  { t:'14:29:55', app:'release-notes',     user:'ci·deploy',       cap:'mcp.github-readonly', model:'—',       out:'ok',      tok:0,    cost:0.001 },
  { t:'14:29:40', app:'demo-acme',         user:'anon·77b2',       cap:'data.write',   model:'—',              out:'denied',  tok:0,    cost:0 },
  { t:'14:29:21', app:'cost-explorer',     user:'kyle@azx.io',     cap:'llm.embeddings', model:'text-embed-3',out:'ok',      tok:900,  cost:0.001 },
  { t:'14:29:03', app:'design-critique',   user:'lee@azx.io',      cap:'llm.chat',     model:'claude-fable-5', out:'ok',      tok:7100, cost:0.071 },
  { t:'14:28:46', app:'incidents',         user:'theo@azx.io',     cap:'mcp.pagerduty',model:'—',              out:'ok',      tok:0,    cost:0.003 },
  { t:'14:28:22', app:'standup',           user:'dana@azx.io',     cap:'data.read',    model:'—',              out:'ok',      tok:0,    cost:0 },
];

// ---- Approvals queue: elevated grants + go-public requests ----------
const APPROVALS = [
  { id:'apr-1', kind:'go-public', app:'status-page', owner:'Dana L.', ago:'18m', risk:'high',
    summary:'Make Status Page publicly reachable (no SSO gate).',
    detail:'Public apps get anonymous-tier quotas + per-IP limits and lose user-scoped storage. Highest-risk action in the system.',
    diff:[['visibility','group:eng-team','public']] },
  { id:'apr-2', kind:'mcp-grant', app:'incident-timeline', owner:'Theo K.', ago:'24m', risk:'med',
    summary:'Grant MCP server: pagerduty',
    detail:'App requests the pagerduty MCP passthrough to read incident streams. Any-MCP grants require admin approval.',
    diff:[['mcp','[]','[pagerduty]']] },
  { id:'apr-3', kind:'origin-grant', app:'incident-timeline', owner:'Theo K.', ago:'24m', risk:'low',
    summary:'Add external origin: api.statuspage.io',
    detail:'Adds a connect-src CSP exception. Routine third-party fetches are funneled through the gateway fetch-proxy.',
    diff:[['external_origins','[]','[api.statuspage.io]']] },
  { id:'apr-4', kind:'llm-budget', app:'design-critique', owner:'Mara S.', ago:'2h', risk:'med',
    summary:'Raise LLM budget 3M → 6M tokens/day',
    detail:'High LLM budgets above the baseline require approval. Current usage is 2.91M/day, trending up.',
    diff:[['llm.tokens_per_day','3,000,000','6,000,000']] },
];

// ---- CSP violation reports → click-to-request -----------------------
const VIOLATIONS = [
  { id:'v-1', app:'design-critique', directive:'connect-src', blocked:'https://api.weather.com/v1/forecast', count:142, last:'3m', requested:false,
    plain:'Your app tried to call api.weather.com and was blocked.' },
  { id:'v-2', app:'cost-explorer', directive:'connect-src', blocked:'https://api.exchangerate.host/latest', count:38, last:'27m', requested:false,
    plain:'Cost Explorer tried to call api.exchangerate.host and was blocked.' },
  { id:'v-3', app:'standup-bot', directive:'connect-src', blocked:'https://hooks.slack.com/services/…', count:9, last:'1h', requested:true,
    plain:'Standup Bot tried to POST to hooks.slack.com — capability request filed.' },
  { id:'v-4', app:'incident-timeline', directive:'connect-src', blocked:'https://api.statuspage.io/v1', count:61, last:'24m', requested:true,
    plain:'Incident Timeline tried to call api.statuspage.io — capability request filed.' },
  { id:'v-5', app:'design-critique', directive:'form-action', blocked:'https://evil-collector.example', count:3, last:'2h', requested:false,
    plain:'Blocked a cross-origin form POST — possible exfiltration attempt.', danger:true },
];

// ---- Platform usage series (admin dashboard) ------------------------
const PLATFORM = {
  tokens14d:[1.1,1.3,1.2,1.6,1.9,1.7,2.2,2.4,2.1,2.8,3.1,2.9,3.4,3.8], // millions
  requests14d:[58,62,60,71,78,74,86,92,88,101,108,104,118,131],          // thousands
  costByApp:[
    { app:'design-critique', cost:184.20, pct:38 },
    { app:'cost-explorer',   cost:121.40, pct:25 },
    { app:'standup-bot',     cost:58.10,  pct:12 },
    { app:'incident-timeline',cost:43.90, pct:9 },
    { app:'release-notes',   cost:34.70,  pct:7 },
    { app:'customer-demo',   cost:24.30,  pct:5 },
    { app:'status-page',     cost:19.80,  pct:4 },
  ],
  totals:{ apps:8, live:6, mtdCost:486.40, tokensMTD:'48.2M', requestsMTD:'1.94M', activeUsers:71 },
};

const ROLES = { OWNER:'owner', ADMIN:'admin' };

Object.assign(window, { APPS, VERSIONS, versionsFor, AUDIT, APPROVALS, VIOLATIONS, PLATFORM, ROLES });
