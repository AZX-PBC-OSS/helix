// ============================================================
// AZX — shared primitives. Exported to window for cross-file use.
// ============================================================
const { useState, useEffect, useRef, useMemo } = React;

// ---- Icons (inline stroke set, 1.6 weight) --------------------------
function Icon({ name, size=16, style }){
  const p = { width:size, height:size, viewBox:'0 0 24 24', fill:'none', stroke:'currentColor',
    strokeWidth:1.7, strokeLinecap:'round', strokeLinejoin:'round', style };
  const paths = {
    grid:<><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
    box:<><path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5"/><path d="M12 13v8"/></>,
    upload:<><path d="M12 16V4"/><path d="m6 10 6-6 6 6"/><path d="M4 18v2h16v-2"/></>,
    gauge:<><path d="M12 14a2 2 0 1 0 0-4"/><path d="m14 12 4-3"/><path d="M5.5 18a9 9 0 1 1 13 0"/></>,
    layers:<><path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 13 9 5 9-5"/></>,
    shield:<><path d="M12 3 5 6v5c0 4 3 7 7 8 4-1 7-4 7-8V6l-7-3z"/></>,
    activity:<path d="M3 12h4l3 8 4-16 3 8h4"/>,
    list:<><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></>,
    alert:<><path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4"/><circle cx="12" cy="17" r=".6" fill="currentColor"/></>,
    settings:<><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7.5 19a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3 13.5a1.6 1.6 0 0 0-1.5-1H1a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 3 7.5a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 8 3V3a2 2 0 1 1 4 0v.1A1.6 1.6 0 0 0 15 4.5a1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1h.1a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.4 1z"/></>,
    search:<><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>,
    chevR:<path d="m9 6 6 6-6 6"/>,
    chevD:<path d="m6 9 6 6 6-6"/>,
    check:<path d="m5 12 5 5 9-11"/>,
    x:<path d="M6 6l12 12M18 6 6 18"/>,
    arrowU:<><path d="M12 19V5"/><path d="m6 11 6-6 6 6"/></>,
    arrowback:<><path d="M9 5 3 12l6 7"/><path d="M3 12h13a5 5 0 0 1 0 10h-1"/></>,
    rotate:<><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></>,
    dot:<circle cx="12" cy="12" r="4" fill="currentColor" stroke="none"/>,
    plus:<><path d="M12 5v14M5 12h14"/></>,
    ext:<><path d="M14 4h6v6"/><path d="M20 4 10 14"/><path d="M18 14v6H4V6h6"/></>,
    user:<><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    lock:<><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    globe:<><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></>,
    key:<><circle cx="8" cy="14" r="4"/><path d="m11 11 9-9 2 2-2 2 2 2-2 2-2-2-3 3"/></>,
    bolt:<path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z"/>,
    clock:<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    db:<><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></>,
    cpu:<><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></>,
    filter:<path d="M3 5h18l-7 8v6l-4-2v-4z"/>,
    copy:<><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/></>,
    terminal:<><path d="M5 5 9 9l-4 4"/><path d="M11 15h6"/><rect x="2" y="3" width="20" height="18" rx="2"/></>,
    flag:<><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></>,
  };
  return <svg {...p}>{paths[name]||null}</svg>;
}

// ---- StatusDot ------------------------------------------------------
const STATUS = {
  healthy:{ c:'var(--live)', label:'Healthy' },
  live:{ c:'var(--live)', label:'Live' },
  degraded:{ c:'var(--warn)', label:'Degraded' },
  disabled:{ c:'var(--fg-3)', label:'Disabled' },
  preview:{ c:'var(--violet)', label:'Preview' },
};
function StatusDot({ kind='healthy', pulse=true, size=8 }){
  const s = STATUS[kind]||STATUS.healthy;
  return <span style={{ display:'inline-block', width:size, height:size, borderRadius:'50%', background:s.c,
    boxShadow:`0 0 0 3px color-mix(in srgb, ${s.c} 18%, transparent)`,
    animation: pulse && (kind==='healthy'||kind==='live') ? 'az-pulse 2.4s ease-in-out infinite' : 'none' }} />;
}

// ---- Badge ----------------------------------------------------------
const BADGE = {
  neutral:['var(--fg-2)','rgba(255,255,255,.06)','var(--line-2)'],
  live:['var(--live)','var(--live-dim)','transparent'],
  warn:['var(--warn)','var(--warn-dim)','transparent'],
  bad:['var(--bad)','var(--bad-dim)','transparent'],
  info:['var(--info)','var(--info-dim)','transparent'],
  violet:['var(--violet)','var(--violet-dim)','transparent'],
  acc:['var(--acc)','var(--acc-dim)','var(--acc-line)'],
};
function Badge({ tone='neutral', children, icon, mono=true, style }){
  const [c,bg,bd] = BADGE[tone]||BADGE.neutral;
  return <span style={{ display:'inline-flex', alignItems:'center', gap:5, color:c, background:bg,
    border:`1px solid ${bd}`, padding:'3px 8px', borderRadius:999, fontSize:11, fontWeight:600,
    fontFamily: mono?'var(--font-mono)':'inherit', letterSpacing: mono?'.02em':0, lineHeight:1.4,
    whiteSpace:'nowrap', ...style }}>
    {icon && <Icon name={icon} size={12}/>}{children}
  </span>;
}

// Visibility badge mapping
function VisBadge({ v, group }){
  const map = {
    private:['lock','neutral','Private'],
    group:['user','info',`Group · ${group||''}`],
    password:['key','warn','Password'],
    public:['globe','acc','Public'],
  };
  const [ic,tone,label] = map[v]||map.private;
  return <Badge tone={tone} icon={ic}>{label}</Badge>;
}

// ---- Button ---------------------------------------------------------
function Button({ variant='ghost', size='md', icon, iconR, children, onClick, style, title, disabled }){
  const [hover,setHover] = useState(false);
  const sz = size==='sm'?{ h:30, px:11, fs:12.5 } : size==='lg'?{ h:42, px:18, fs:14.5 } : { h:36, px:14, fs:13.5 };
  const base = { display:'inline-flex', alignItems:'center', justifyContent:'center', gap:7,
    height:sz.h, padding:`0 ${sz.px}px`, fontSize:sz.fs, fontWeight:600, borderRadius:8,
    border:'1px solid transparent', transition:'all .14s ease', whiteSpace:'nowrap',
    opacity:disabled?.45:1, pointerEvents:disabled?'none':'auto', fontFamily:'var(--font-ui)' };
  const variants = {
    primary:{ background:'var(--acc)', color:'var(--acc-ink)', boxShadow:hover?'0 0 24px -4px var(--acc-line)':'none', transform:hover?'translateY(-1px)':'none' },
    solid:{ background:hover?'var(--bg-4)':'var(--bg-3)', color:'var(--fg)', borderColor:'var(--line-2)' },
    ghost:{ background:hover?'rgba(255,255,255,.05)':'transparent', color:hover?'var(--fg)':'var(--fg-2)', borderColor:'var(--line)' },
    subtle:{ background:'transparent', color:hover?'var(--fg)':'var(--fg-3)', borderColor:'transparent' },
    danger:{ background:hover?'var(--bad-dim)':'transparent', color:'var(--bad)', borderColor:'var(--bad-dim)' },
  };
  return <button title={title} onClick={onClick} disabled={disabled}
    onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
    style={{ ...base, ...variants[variant], ...style }}>
    {icon && <Icon name={icon} size={size==='sm'?13:15}/>}{children}{iconR && <Icon name={iconR} size={size==='sm'?13:15}/>}
  </button>;
}

// ---- Card / Panel ---------------------------------------------------
function Card({ children, style, pad=true, hover=false, onClick }){
  const [h,setH] = useState(false);
  return <div onClick={onClick}
    onMouseEnter={()=>hover&&setH(true)} onMouseLeave={()=>hover&&setH(false)}
    style={{ background:'var(--bg-1)', border:`1px solid ${h?'var(--line-3)':'var(--line)'}`,
      borderRadius:'var(--r-lg)', padding:pad?'var(--pad)':0, boxShadow:'var(--shadow)',
      transition:'border-color .16s ease, transform .16s ease', transform:h?'translateY(-2px)':'none',
      cursor:onClick?'pointer':'default', position:'relative', ...style }}>
    {children}
  </div>;
}

// ---- Stat ----------------------------------------------------------
function Stat({ label, value, unit, sub, tone, icon }){
  return <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
    <div style={{ display:'flex', alignItems:'center', gap:6 }} className="eyebrow">
      {icon && <Icon name={icon} size={12} style={{ color:'var(--fg-3)' }}/>}{label}
    </div>
    <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
      <span className="mono tnum" style={{ fontSize:26, fontWeight:600, color:tone||'var(--fg)', letterSpacing:'-.02em' }}>{value}</span>
      {unit && <span className="mono" style={{ fontSize:12, color:'var(--fg-3)' }}>{unit}</span>}
    </div>
    {sub && <div style={{ fontSize:12, color:'var(--fg-3)' }}>{sub}</div>}
  </div>;
}

// ---- Sparkline ------------------------------------------------------
function Sparkline({ data, w=120, h=34, stroke='var(--acc)', fill=true, dot=false }){
  const max = Math.max(...data,1), min = Math.min(...data,0);
  const rng = max-min||1;
  const pts = data.map((d,i)=>[ (i/(data.length-1))*w, h-2 - ((d-min)/rng)*(h-4) ]);
  const path = pts.map((p,i)=>`${i?'L':'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area = `${path} L${w} ${h} L0 ${h} Z`;
  const id = useMemo(()=>'sg'+Math.random().toString(36).slice(2,7),[]);
  return <svg width={w} height={h} style={{ display:'block', overflow:'visible' }}>
    <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stopColor={stroke} stopOpacity=".22"/><stop offset="100%" stopColor={stroke} stopOpacity="0"/>
    </linearGradient></defs>
    {fill && <path d={area} fill={`url(#${id})`}/>}
    <path d={path} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round"/>
    {dot && <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="2.6" fill={stroke}/>}
  </svg>;
}

// ---- Bars (mini column chart) --------------------------------------
function Bars({ data, w=240, h=70, color='var(--acc)' }){
  const max = Math.max(...data,1);
  const bw = w/data.length;
  return <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ display:'block' }}>
    {data.map((d,i)=>{ const bh=(d/max)*(h-4); return (
      <rect key={i} x={i*bw+1.5} y={h-bh} width={bw-3} height={bh} rx="1.5"
        fill={i===data.length-1?color:'color-mix(in srgb, '+'var(--fg-3)'+' 55%, transparent)'}
        opacity={i===data.length-1?1:.5} />
    );})}
  </svg>;
}

// ---- Progress / meter ----------------------------------------------
function Meter({ pct, tone, h=6 }){
  const c = tone || (pct>92?'var(--bad)':pct>78?'var(--warn)':'var(--acc)');
  return <div style={{ height:h, borderRadius:99, background:'var(--bg-3)', overflow:'hidden' }}>
    <div style={{ width:Math.min(pct,100)+'%', height:'100%', background:c, borderRadius:99, transition:'width .5s ease' }}/>
  </div>;
}

// ---- Tabs -----------------------------------------------------------
function Tabs({ tabs, active, onChange }){
  return <div style={{ display:'flex', gap:2, borderBottom:'1px solid var(--line)', marginBottom:'var(--gap)' }}>
    {tabs.map(t=>{ const on = t.id===active; return (
      <button key={t.id} onClick={()=>onChange(t.id)} style={{ position:'relative', background:'none',
        border:'none', padding:'10px 14px', fontSize:13.5, fontWeight:on?600:500, color:on?'var(--fg)':'var(--fg-3)',
        fontFamily:'var(--font-ui)', display:'flex', alignItems:'center', gap:7, transition:'color .14s' }}>
        {t.icon && <Icon name={t.icon} size={15}/>}{t.label}
        {t.count!=null && <span className="mono" style={{ fontSize:11, color:on?'var(--acc)':'var(--fg-4)' }}>{t.count}</span>}
        {on && <span style={{ position:'absolute', left:0, right:0, bottom:-1, height:2, background:'var(--acc)', borderRadius:2 }}/>}
      </button>
    );})}
  </div>;
}

// ---- Key/Value row --------------------------------------------------
function KV({ k, children, mono=false }){
  return <div style={{ display:'flex', justifyContent:'space-between', gap:16, padding:'9px 0', borderBottom:'1px solid var(--line)', alignItems:'center' }}>
    <span style={{ color:'var(--fg-3)', fontSize:13, whiteSpace:'nowrap' }}>{k}</span>
    <span className={mono?'mono':''} style={{ color:'var(--fg)', fontSize:13, textAlign:'right', whiteSpace:'nowrap' }}>{children}</span>
  </div>;
}

// ---- Page header ----------------------------------------------------
function PageHead({ eyebrow, title, sub, actions }){
  return <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', gap:20, marginBottom:'calc(var(--gap) + 6px)', flexWrap:'wrap' }}>
    <div>
      {eyebrow && <div className="eyebrow" style={{ marginBottom:8 }}>{eyebrow}</div>}
      <h1 style={{ fontSize:27, fontWeight:600 }}>{title}</h1>
      {sub && <p style={{ margin:'8px 0 0', color:'var(--fg-3)', fontSize:14, maxWidth:560 }}>{sub}</p>}
    </div>
    {actions && <div style={{ display:'flex', gap:10, alignItems:'center' }}>{actions}</div>}
  </div>;
}

// ---- Empty / hint banner -------------------------------------------
function Hint({ icon='shield', children, tone='info', action }){
  const [c,bg] = (BADGE[tone]||BADGE.info);
  return <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px', borderRadius:'var(--r-md)',
    background:bg, border:`1px solid color-mix(in srgb, ${c} 22%, transparent)`, color:'var(--fg-2)', fontSize:13 }}>
    <Icon name={icon} size={17} style={{ color:c, flexShrink:0 }}/>
    <span style={{ flex:1 }}>{children}</span>
    {action}
  </div>;
}

// ---- Risk pill ------------------------------------------------------
function Risk({ level }){
  const m = { high:['bad','HIGH RISK'], med:['warn','ELEVATED'], low:['info','ROUTINE'] };
  const [tone,label] = m[level]||m.low;
  return <Badge tone={tone}>{label}</Badge>;
}

Object.assign(window, { Icon, StatusDot, STATUS, Badge, VisBadge, Button, Card, Stat,
  Sparkline, Bars, Meter, Tabs, KV, PageHead, Hint, Risk,
  useState, useEffect, useRef, useMemo });
