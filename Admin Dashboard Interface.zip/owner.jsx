// ============================================================
// AZX — Owner experience: app list, app detail (overview / versions
// + rollback / manifest editor / usage / settings), owner usage.
// ============================================================

function fmt(n){ return n>=1e6?(n/1e6).toFixed(2)+'M':n>=1e3?(n/1e3).toFixed(1)+'k':String(n); }

// ---- App card (dashboard) ------------------------------------------
function AppCard({ app, onOpen }){
  const pct = app.use.tokBudget ? Math.round(app.use.tokDay/app.use.tokBudget*100) : 0;
  return <Card hover onClick={onOpen} style={{ display:'flex', flexDirection:'column', gap:14 }}>
    <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
      <div style={{ display:'flex', gap:12, minWidth:0, flex:1 }}>
        <div style={{ width:38, height:38, borderRadius:10, background:'var(--bg-3)', border:'1px solid var(--line-2)',
          display:'grid', placeItems:'center', flexShrink:0, color:'var(--fg-2)', fontFamily:'var(--font-disp)', fontWeight:600, fontSize:15 }}>
          {app.name[0]}
        </div>
        <div style={{ minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:0 }}>
            <span style={{ fontWeight:600, fontSize:15, fontFamily:'var(--font-disp)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{app.name}</span>
          </div>
          <div className="mono" style={{ fontSize:11.5, color:'var(--fg-3)', marginTop:3, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{app.sub}.azx-labs.com</div>
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:7, flexShrink:0 }}>
        <StatusDot kind={app.status==='live'?app.health:app.status}/>
        <span style={{ fontSize:12, color:'var(--fg-2)', fontWeight:500 }}>{(STATUS[app.status==='live'?app.health:app.status]||STATUS.healthy).label}</span>
      </div>
    </div>

    <p style={{ margin:0, fontSize:13, color:'var(--fg-3)', lineHeight:1.45, minHeight:38 }}>{app.desc}</p>

    <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
      <VisBadge v={app.visibility} group={app.group}/>
      {app.flags.includes('preview') && <Badge tone="violet" icon="layers">preview {app.preview}</Badge>}
      {app.flags.includes('quota-near') && <Badge tone="warn" icon="gauge">quota {pct}%</Badge>}
      {app.flags.includes('awaiting-promote') && <Badge tone="violet">awaiting promote</Badge>}
    </div>

    <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', borderTop:'1px solid var(--line)', paddingTop:13 }}>
      <div style={{ display:'flex', gap:20 }}>
        <div>
          <div className="eyebrow" style={{ fontSize:9.5 }}>Req / day</div>
          <div className="mono tnum" style={{ fontSize:15, fontWeight:600, marginTop:3 }}>{fmt(app.use.reqDay)}</div>
        </div>
        <div>
          <div className="eyebrow" style={{ fontSize:9.5 }}>Tokens</div>
          <div className="mono tnum" style={{ fontSize:15, fontWeight:600, marginTop:3 }}>{app.use.tokBudget?fmt(app.use.tokDay):'—'}</div>
        </div>
      </div>
      <Sparkline data={app.spark} w={92} h={32} stroke={app.health==='degraded'?'var(--warn)':app.status==='disabled'?'var(--fg-4)':'var(--acc)'} dot/>
    </div>
  </Card>;
}

function OwnerApps({ go, openDeploy }){
  const [filter,setFilter] = useState('all');
  const mine = APPS;
  const counts = { all:mine.length, live:mine.filter(a=>a.status==='live').length,
    preview:mine.filter(a=>a.flags.includes('preview')||a.status==='preview').length,
    private:mine.filter(a=>a.visibility==='private').length };
  const shown = filter==='all'?mine : filter==='live'?mine.filter(a=>a.status==='live')
    : filter==='preview'?mine.filter(a=>a.flags.includes('preview')||a.status==='preview')
    : mine.filter(a=>a.visibility===filter);

  return <div>
    <PageHead eyebrow="Workspace · azx-labs.com" title="My Apps"
      sub="Static frontends hosted behind SSO. All dynamic capability flows through the platform gateway."
      actions={<>
        <Button variant="ghost" icon="terminal" size="md">Get deploy skill</Button>
        <Button variant="primary" icon="upload" size="md" onClick={openDeploy}>Deploy app</Button>
      </>}/>

    {/* stat strip */}
    <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'var(--gap)', marginBottom:'calc(var(--gap) + 6px)' }} className="stagger">
      <Card><Stat icon="grid" label="Apps owned" value={mine.length} sub={`${counts.live} live · 1 preview · 1 disabled`}/></Card>
      <Card><Stat icon="bolt" label="Requests today" value="29.5" unit="k" sub="across all apps"/></Card>
      <Card><Stat icon="cpu" label="LLM tokens today" value="4.61" unit="M" sub="of 7.3M granted budget"/></Card>
      <Card><Stat icon="shield" label="Open items" value="3" tone="var(--warn)" sub="1 quota · 1 promote · 1 violation"/></Card>
    </div>

    {/* filter row */}
    <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'var(--gap)' }}>
      {[['all','All'],['live','Live'],['preview','Preview'],['private','Private']].map(([id,l])=>(
        <button key={id} onClick={()=>setFilter(id)} style={{ padding:'6px 12px', borderRadius:8, fontSize:12.5, fontWeight:600,
          fontFamily:'var(--font-ui)', cursor:'pointer', transition:'all .14s',
          background: filter===id?'var(--bg-3)':'transparent', color: filter===id?'var(--fg)':'var(--fg-3)',
          border:`1px solid ${filter===id?'var(--line-2)':'var(--line)'}` }}>
          {l} <span className="mono" style={{ color:'var(--fg-4)', fontSize:11 }}>{counts[id]??''}</span>
        </button>
      ))}
      <div style={{ flex:1 }}/>
      <Button variant="subtle" icon="filter" size="sm">Sort: Activity</Button>
    </div>

    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(330px,1fr))', gap:'var(--gap)' }} className="stagger">
      {shown.map(a=><AppCard key={a.id} app={a} onOpen={()=>go('app:'+a.id)}/>)}
    </div>
  </div>;
}

// ===================================================================
// APP DETAIL
// ===================================================================
function AppDetail({ id, go, openDeploy }){
  const app = APPS.find(a=>a.id===id) || APPS[0];
  const [tab,setTab] = useState('overview');
  const tabs = [
    { id:'overview', label:'Overview', icon:'grid' },
    { id:'versions', label:'Versions', icon:'layers', count: versionsFor(app.id).length },
    { id:'manifest', label:'Capabilities', icon:'shield' },
    { id:'usage',    label:'Usage', icon:'gauge' },
    { id:'settings', label:'Settings', icon:'settings' },
  ];
  return <div>
    {/* breadcrumb + header */}
    <button onClick={()=>go('apps')} style={{ display:'inline-flex', alignItems:'center', gap:7, background:'none', border:'none',
      color:'var(--fg-3)', fontSize:12.5, fontFamily:'var(--font-ui)', cursor:'pointer', marginBottom:16, padding:0, whiteSpace:'nowrap' }}>
      <Icon name="chevR" size={13} style={{ transform:'rotate(180deg)' }}/> My Apps
    </button>

    <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:20, marginBottom:24, flexWrap:'wrap' }}>
      <div style={{ display:'flex', gap:16 }}>
        <div style={{ width:52, height:52, borderRadius:13, background:'var(--bg-3)', border:'1px solid var(--line-2)',
          display:'grid', placeItems:'center', flexShrink:0, color:'var(--fg)', fontFamily:'var(--font-disp)', fontWeight:600, fontSize:21 }}>{app.name[0]}</div>
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <h1 style={{ fontSize:25 }}>{app.name}</h1>
            <StatusDot kind={app.status==='live'?app.health:app.status}/>
            <span style={{ fontSize:13, color:'var(--fg-2)' }}>{(STATUS[app.status==='live'?app.health:app.status]||STATUS.healthy).label}</span>
          </div>
          <a style={{ display:'inline-flex', alignItems:'center', gap:7, marginTop:7, color:'var(--acc)', fontSize:13, fontFamily:'var(--font-mono)', whiteSpace:'nowrap' }}>
            {app.sub}.azx-labs.com <Icon name="ext" size={13}/>
          </a>
          <div style={{ display:'flex', gap:8, marginTop:12, flexWrap:'wrap' }}>
            <VisBadge v={app.visibility} group={app.group}/>
            <Badge tone="neutral" icon="layers">live {app.live||'—'}</Badge>
            {app.preview && <Badge tone="violet">preview {app.preview}</Badge>}
            <Badge tone="neutral" icon="user">{app.owner}</Badge>
          </div>
        </div>
      </div>
      <div style={{ display:'flex', gap:10 }}>
        <Button variant="ghost" icon="rotate" size="md" onClick={()=>setTab('versions')}>Rollback</Button>
        <Button variant="primary" icon="upload" size="md" onClick={openDeploy}>Deploy</Button>
      </div>
    </div>

    <Tabs tabs={tabs} active={tab} onChange={setTab}/>

    {tab==='overview' && <OverviewTab app={app}/>}
    {tab==='versions' && <VersionsTab app={app}/>}
    {tab==='manifest' && <ManifestTab app={app}/>}
    {tab==='usage' && <UsageTab app={app}/>}
    {tab==='settings' && <SettingsTab app={app} go={go}/>}
  </div>;
}

// ---- Overview tab ---------------------------------------------------
function OverviewTab({ app }){
  const pct = app.use.tokBudget ? Math.round(app.use.tokDay/app.use.tokBudget*100) : 0;
  return <div className="stagger" style={{ display:'grid', gridTemplateColumns:'1.6fr 1fr', gap:'var(--gap)' }}>
    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'var(--gap)' }}>
        <Card><Stat icon="bolt" label="Requests / day" value={fmt(app.use.reqDay)} sub={`err ${app.use.errRate}%`}/></Card>
        <Card><Stat icon="cpu" label="Tokens / day" value={app.use.tokBudget?fmt(app.use.tokDay):'—'} sub={app.use.tokBudget?`of ${fmt(app.use.tokBudget)}`:'no LLM caps'}/></Card>
        <Card><Stat icon="user" label="Users (7d)" value={app.use.users7d||'—'} sub={app.visibility==='public'?'anonymous':'verified'}/></Card>
      </div>
      <Card>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div className="eyebrow">Requests · last 16 intervals</div>
          <Badge tone={app.health==='degraded'?'warn':'live'} icon="dot">{app.health==='degraded'?'Degraded':'Healthy'}</Badge>
        </div>
        <Bars data={app.spark} h={92} color={app.health==='degraded'?'var(--warn)':'var(--acc)'}/>
      </Card>
      {app.flags.includes('awaiting-promote') && <Hint icon="layers" tone="violet" action={<Button variant="ghost" size="sm">Review preview</Button>}>
        <b>{app.preview}</b> is deployed to preview and awaiting promotion. Live traffic is unaffected until you promote.
      </Hint>}
      {app.health==='degraded' && <Hint icon="alert" tone="warn" action={<Button variant="ghost" size="sm">View violations</Button>}>
        Elevated error rate ({app.use.errRate}%) — a blocked <span className="mono">connect-src</span> call to api.weather.com is firing repeatedly.
      </Hint>}
    </div>

    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      <Card>
        <div className="eyebrow" style={{ marginBottom:6 }}>LLM budget</div>
        {app.use.tokBudget ? <>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
            <span className="mono" style={{ fontSize:19, fontWeight:600 }}>{fmt(app.use.tokDay)}</span>
            <span className="mono" style={{ fontSize:12, color:'var(--fg-3)' }}>/ {fmt(app.use.tokBudget)} day</span>
          </div>
          <Meter pct={pct}/>
          <div style={{ fontSize:12, color: pct>78?'var(--warn)':'var(--fg-3)', marginTop:8 }}>{pct}% used · in-flight requests always finish; new ones block at 100%.</div>
        </> : <div style={{ fontSize:13, color:'var(--fg-3)' }}>No LLM capability granted.</div>}
      </Card>
      <Card>
        <div className="eyebrow" style={{ marginBottom:12 }}>Granted capabilities</div>
        <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
          <CapLine icon="cpu" label="LLM models" val={app.caps.llm.models.length?app.caps.llm.models.join(', '):'none'}/>
          <CapLine icon="db" label="Data scope" val={[app.caps.data.app&&'app',app.caps.data.user&&'user'].filter(Boolean).join(' + ')||'none'}/>
          <CapLine icon="key" label="MCP servers" val={app.caps.mcp.length?app.caps.mcp.join(', '):'none'}/>
          <CapLine icon="globe" label="Ext. origins" val={app.caps.origins.length?app.caps.origins.join(', '):'gateway only'}/>
        </div>
      </Card>
      <Card>
        <div className="eyebrow" style={{ marginBottom:4 }}>Last deploy</div>
        <KV k="Version" mono>{app.live||app.preview}</KV>
        <KV k="By" mono>{app.deployedBy}</KV>
        <KV k="When" mono>{app.deployedAgo} ago</KV>
        <div style={{ paddingTop:10 }}><KV k="Storage" mono>{app.use.storage}</KV></div>
      </Card>
    </div>
  </div>;
}
function CapLine({ icon, label, val }){
  return <div style={{ display:'flex', alignItems:'center', gap:10 }}>
    <Icon name={icon} size={15} style={{ color:'var(--fg-3)', flexShrink:0 }}/>
    <span style={{ fontSize:12.5, color:'var(--fg-3)', width:92, flexShrink:0 }}>{label}</span>
    <span className="mono" style={{ fontSize:12, color:'var(--fg)', textAlign:'right', flex:1 }}>{val}</span>
  </div>;
}

// ---- Versions tab ---------------------------------------------------
function VersionsTab({ app }){
  const vs = versionsFor(app.id);
  const [confirm,setConfirm] = useState(null);
  return <div className="stagger">
    <Hint icon="layers" tone="info">Every deploy is an <b>immutable version</b> in Blob storage. “Deploy” flips the registry pointer; rollback flips it back — no rebuild.</Hint>
    <div style={{ marginTop:'var(--gap)', border:'1px solid var(--line)', borderRadius:'var(--r-lg)', overflow:'hidden', background:'var(--bg-1)' }}>
      <div style={{ display:'grid', gridTemplateColumns:'90px 1fr 110px 130px 90px 120px', gap:12, padding:'11px 18px',
        borderBottom:'1px solid var(--line)', background:'var(--bg-2)' }} className="eyebrow">
        <span>Version</span><span>Change</span><span>Via</span><span>By</span><span>Size</span><span style={{ textAlign:'right' }}>Action</span>
      </div>
      {vs.map((v,i)=>(
        <div key={v.v} style={{ display:'grid', gridTemplateColumns:'90px 1fr 110px 130px 90px 120px', gap:12,
          padding:'13px 18px', borderBottom: i<vs.length-1?'1px solid var(--line)':'none', alignItems:'center',
          background: v.state==='live'?'var(--acc-dim)':'transparent' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span className="mono" style={{ fontSize:13, fontWeight:600 }}>{v.v}</span>
            {v.state==='live' && <Badge tone="live" style={{ padding:'1px 6px', fontSize:9.5 }}>LIVE</Badge>}
          </div>
          <div style={{ minWidth:0 }}>
            <div style={{ fontSize:13, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{v.note}</div>
            <div className="mono" style={{ fontSize:11, color:'var(--fg-4)', marginTop:2 }}>{v.sha} · {v.files} files</div>
          </div>
          <Badge tone={v.via==='agent'?'violet':v.via==='ci'?'info':'neutral'} icon={v.via==='cli'||v.via==='ci'?'terminal':v.via==='agent'?'bolt':'upload'}>{v.via}</Badge>
          <span className="mono" style={{ fontSize:12, color:'var(--fg-2)' }}>{v.by} · {v.ago}</span>
          <span className="mono" style={{ fontSize:12, color:'var(--fg-3)' }}>{v.size}</span>
          <div style={{ textAlign:'right' }}>
            {v.state==='live' ? <span className="mono" style={{ fontSize:11, color:'var(--fg-4)' }}>serving</span>
              : <Button variant="ghost" size="sm" icon="rotate" onClick={()=>setConfirm(v)}>Rollback</Button>}
          </div>
        </div>
      ))}
    </div>

    {confirm && <Overlay onClose={()=>setConfirm(null)} align="center">
      <div style={{ alignSelf:'center', width:420, background:'var(--bg-1)', border:'1px solid var(--line-2)', borderRadius:'var(--r-xl)',
        padding:26, animation:'az-pop .22s cubic-bezier(.2,.7,.3,1)', boxShadow:'0 40px 120px -40px #000' }}>
        <div style={{ width:44, height:44, borderRadius:12, background:'var(--warn-dim)', color:'var(--warn)', display:'grid', placeItems:'center', marginBottom:14 }}><Icon name="rotate" size={22}/></div>
        <h3 style={{ fontSize:17 }}>Roll back to {confirm.v}?</h3>
        <p style={{ color:'var(--fg-3)', fontSize:13.5, marginTop:8, lineHeight:1.5 }}>This flips the live pointer from <span className="mono" style={{ color:'var(--fg)' }}>{app.live}</span> to <span className="mono" style={{ color:'var(--fg)' }}>{confirm.v}</span> instantly. The bundle is already in storage — nothing rebuilds.</p>
        <div style={{ display:'flex', gap:10, marginTop:20, justifyContent:'flex-end' }}>
          <Button variant="subtle" onClick={()=>setConfirm(null)}>Cancel</Button>
          <Button variant="primary" icon="rotate" onClick={()=>setConfirm(null)}>Flip to {confirm.v}</Button>
        </div>
      </div>
    </Overlay>}
  </div>;
}

// ---- Manifest (capabilities) tab -----------------------------------
function ManifestTab({ app }){
  const c = app.caps;
  const yaml = `app: ${app.id}
visibility: ${app.visibility}${app.group?`:${app.group}`:''}
capabilities:
  llm:
    models: [${c.llm.models.join(', ')}]
    tokens_per_day: ${c.llm.tokens.toLocaleString()}
  data:
    app_scope: ${c.data.app}
    user_scope: ${c.data.user}
  mcp: [${c.mcp.join(', ')}]
  external_origins: [${c.origins.join(', ')}]`;
  return <div className="stagger" style={{ display:'grid', gridTemplateColumns:'1fr 380px', gap:'var(--gap)' }}>
    {/* editor */}
    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      <CapBlock icon="cpu" title="LLM inference" desc="Proxied to Azure OpenAI / Anthropic. The platform holds vendor keys — your app never sees them.">
        <ChipRow label="Models" chips={c.llm.models.length?c.llm.models:['—']} add="add model"/>
        <div style={{ marginTop:14 }}>
          <div className="eyebrow" style={{ marginBottom:8 }}>Token budget / day</div>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <input type="range" min="0" max="6000000" defaultValue={c.llm.tokens} style={{ flex:1, accentColor:'var(--acc)' }}/>
            <span className="mono" style={{ fontSize:13, fontWeight:600, width:70, textAlign:'right' }}>{fmt(c.llm.tokens)}</span>
          </div>
          {c.llm.tokens>2_000_000 && <div style={{ fontSize:12, color:'var(--warn)', marginTop:8, display:'flex', alignItems:'center', gap:6 }}><Icon name="shield" size={13}/>Budgets above 2M require platform-admin approval.</div>}
        </div>
      </CapBlock>

      <CapBlock icon="db" title="App data storage" desc="App- and user-scoped KV/document storage. Removes the need for a custom backend. User-scoped data is partitioned by the authenticated user.">
        <Toggle label="App-scoped store" desc="/_api/data/app/*" on={c.data.app}/>
        <Toggle label="User-scoped store" desc="/_api/data/user/* — auto-partitioned per user" on={c.data.user}/>
      </CapBlock>

      <CapBlock icon="key" title="MCP servers" desc="Platform-registered MCP servers exposed as governed REST endpoints. Any-MCP grants need admin approval.">
        <ChipRow label="Granted" chips={c.mcp.length?c.mcp:['none']} add="request MCP" approval/>
      </CapBlock>

      <CapBlock icon="globe" title="External origins" desc="Adds connect-src CSP exceptions. Prefer the gateway fetch-proxy — it adds auditing, metering, and server-side secrets.">
        <ChipRow label="connect-src" chips={c.origins.length?c.origins:['gateway only']} add="request origin" approval/>
      </CapBlock>
    </div>

    {/* live yaml */}
    <div>
      <div style={{ position:'sticky', top:0 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
          <div className="eyebrow">manifest.yaml · v3</div>
          <Button variant="subtle" icon="copy" size="sm">Copy</Button>
        </div>
        <pre style={{ margin:0, background:'#06070a', border:'1px solid var(--line)', borderRadius:'var(--r-md)',
          padding:'16px 18px', fontFamily:'var(--font-mono)', fontSize:12, lineHeight:1.7, color:'var(--fg-2)', overflowX:'auto', whiteSpace:'pre' }}>{yaml}</pre>
        <Hint icon="shield" tone="info" >Manifests are versioned. Saving a change above the baseline opens an approval request to platform admins.</Hint>
        <Button variant="primary" size="md" icon="check" style={{ width:'100%', marginTop:14 }}>Save manifest</Button>
      </div>
    </div>
  </div>;
}
function CapBlock({ icon, title, desc, children }){
  return <Card>
    <div style={{ display:'flex', gap:11, marginBottom:14 }}>
      <div style={{ width:34, height:34, borderRadius:9, background:'var(--bg-3)', display:'grid', placeItems:'center', color:'var(--acc)', flexShrink:0 }}><Icon name={icon} size={17}/></div>
      <div>
        <div style={{ fontWeight:600, fontSize:14.5, fontFamily:'var(--font-disp)' }}>{title}</div>
        <p style={{ margin:'4px 0 0', fontSize:12.5, color:'var(--fg-3)', lineHeight:1.45 }}>{desc}</p>
      </div>
    </div>
    {children}
  </Card>;
}
function ChipRow({ label, chips, add, approval }){
  return <div>
    <div className="eyebrow" style={{ marginBottom:8 }}>{label}</div>
    <div style={{ display:'flex', flexWrap:'wrap', gap:8, alignItems:'center' }}>
      {chips.map((c,i)=><span key={i} className="mono" style={{ fontSize:12, padding:'5px 10px', borderRadius:7,
        background: c==='none'||c==='—'||c==='gateway only'?'transparent':'var(--bg-3)',
        border:`1px solid ${c==='none'||c==='—'||c==='gateway only'?'var(--line)':'var(--line-2)'}`,
        color: c==='none'||c==='—'||c==='gateway only'?'var(--fg-4)':'var(--fg)', display:'inline-flex', alignItems:'center', gap:7 }}>
        {c}{!(c==='none'||c==='—'||c==='gateway only') && <Icon name="x" size={11} style={{ color:'var(--fg-4)', cursor:'pointer' }}/>}
      </span>)}
      <button style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:7, fontSize:12,
        fontFamily:'var(--font-ui)', background:'transparent', border:'1px dashed var(--line-3)', color:'var(--fg-3)', cursor:'pointer' }}>
        <Icon name="plus" size={12}/>{add}{approval && <Badge tone="violet" style={{ padding:'0 5px', fontSize:8.5, marginLeft:2 }}>APPROVAL</Badge>}
      </button>
    </div>
  </div>;
}
function Toggle({ label, desc, on:initial }){
  const [on,setOn] = useState(initial);
  return <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:14, padding:'9px 0', borderBottom:'1px solid var(--line)' }}>
    <div style={{ flex:1, minWidth:0 }}><div style={{ fontSize:13.5, fontWeight:500, whiteSpace:'nowrap' }}>{label}</div><div className="mono" style={{ fontSize:11, color:'var(--fg-3)', marginTop:2 }}>{desc}</div></div>
    <button onClick={()=>setOn(!on)} style={{ width:40, height:23, borderRadius:99, border:'none', cursor:'pointer', flexShrink:0,
      background: on?'var(--acc)':'var(--bg-4)', position:'relative', transition:'background .18s' }}>
      <span style={{ position:'absolute', top:3, left: on?20:3, width:17, height:17, borderRadius:'50%', background:'#fff', transition:'left .18s' }}/>
    </button>
  </div>;
}

// ---- Usage tab ------------------------------------------------------
function UsageTab({ app }){
  const pct = app.use.tokBudget ? Math.round(app.use.tokDay/app.use.tokBudget*100) : 0;
  return <div className="stagger">
    <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card><Stat icon="bolt" label="Requests / day" value={fmt(app.use.reqDay)} sub="gateway calls"/></Card>
      <Card><Stat icon="cpu" label="Tokens / day" value={app.use.tokBudget?fmt(app.use.tokDay):'—'} tone={pct>78?'var(--warn)':null} sub={app.use.tokBudget?`${pct}% of budget`:'no LLM'}/></Card>
      <Card><Stat icon="db" label="Storage" value={app.use.storage} sub="app + user scope"/></Card>
      <Card><Stat icon="alert" label="Error rate" value={app.use.errRate+'%'} tone={app.use.errRate>1?'var(--warn)':null} sub="last 24h"/></Card>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--gap)' }}>
      <Card>
        <div className="eyebrow" style={{ marginBottom:14 }}>Requests · 16 intervals</div>
        <Bars data={app.spark} h={120} color="var(--acc)"/>
      </Card>
      <Card>
        <div className="eyebrow" style={{ marginBottom:14 }}>Token consumption · 16 intervals</div>
        <Bars data={app.spark.map(x=>x*1.3+5)} h={120} color="var(--info)"/>
      </Card>
    </div>
    <Card style={{ marginTop:'var(--gap)' }}>
      <div className="eyebrow" style={{ marginBottom:14 }}>Capability breakdown · today</div>
      {[['llm.chat','var(--info)',62],['data.read / write','var(--acc)',24],['mcp.azure-billing','var(--violet)',9],['llm.embeddings','var(--warn)',5]].map(([k,c,p])=>(
        <div key={k} style={{ display:'flex', alignItems:'center', gap:14, padding:'8px 0' }}>
          <span className="mono" style={{ fontSize:12.5, width:160, color:'var(--fg-2)' }}>{k}</span>
          <div style={{ flex:1 }}><Meter pct={p} tone={c}/></div>
          <span className="mono tnum" style={{ fontSize:12.5, width:40, textAlign:'right', color:'var(--fg-3)' }}>{p}%</span>
        </div>
      ))}
    </Card>
  </div>;
}

// ---- Settings tab ---------------------------------------------------
function SettingsTab({ app, go }){
  const [vis,setVis] = useState(app.visibility);
  const opts = [
    ['private','lock','Private','SSO via Entra ID. Unauthenticated users are redirected to login.'],
    ['group','user','Group-restricted','SSO plus an Entra group membership check.'],
    ['password','key','Password','Shared password gate for external demos. Pseudonymous identity.'],
    ['public','globe','Public','No gate. Anonymous-tier quotas + per-IP limits. Requires admin approval.'],
  ];
  return <div className="stagger" style={{ display:'grid', gridTemplateColumns:'1fr 340px', gap:'var(--gap)', alignItems:'start' }}>
    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      <Card>
        <div className="eyebrow" style={{ marginBottom:4 }}>Visibility</div>
        <p style={{ margin:'0 0 16px', fontSize:13, color:'var(--fg-3)' }}>Auth is terminated at the edge proxy — your app ships zero auth code.</p>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {opts.map(([id,ic,label,desc])=>{ const on=vis===id; return (
            <button key={id} onClick={()=>setVis(id)} style={{ display:'flex', gap:13, alignItems:'flex-start', textAlign:'left',
              padding:'13px 14px', borderRadius:'var(--r-md)', cursor:'pointer', transition:'all .14s',
              background: on?'var(--acc-dim)':'var(--bg-2)', border:`1px solid ${on?'var(--acc-line)':'var(--line)'}` }}>
              <div style={{ width:30, height:30, borderRadius:8, background: on?'var(--acc)':'var(--bg-3)', color: on?'var(--acc-ink)':'var(--fg-2)', display:'grid', placeItems:'center', flexShrink:0 }}><Icon name={ic} size={15}/></div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <span style={{ fontWeight:600, fontSize:13.5 }}>{label}</span>
                  {id==='public' && <Badge tone="violet" style={{ fontSize:8.5, padding:'1px 6px' }}>NEEDS APPROVAL</Badge>}
                </div>
                <div style={{ fontSize:12.5, color:'var(--fg-3)', marginTop:3, lineHeight:1.45 }}>{desc}</div>
              </div>
              <div style={{ width:18, height:18, borderRadius:'50%', border:`2px solid ${on?'var(--acc)':'var(--line-3)'}`, display:'grid', placeItems:'center', flexShrink:0, marginTop:2 }}>
                {on && <span style={{ width:8, height:8, borderRadius:'50%', background:'var(--acc)' }}/>}
              </div>
            </button>
          );})}
        </div>
        {vis==='public' && vis!==app.visibility && <Hint icon="shield" tone="warn" >Going public is the highest-risk action in the system — it files an approval request to platform admins.</Hint>}
      </Card>

      <Card>
        <div className="eyebrow" style={{ marginBottom:14 }}>Deploy guardrail</div>
        <Toggle label="Agent deploys land on preview" desc="Promote to live takes a human action in the portal" on={true}/>
        <Toggle label="Allow static deploy tokens" desc="azxd_… prefixed, expiring, shown once — off by default" on={false}/>
      </Card>
    </div>

    <div style={{ display:'flex', flexDirection:'column', gap:'var(--gap)' }}>
      <Card>
        <div className="eyebrow" style={{ marginBottom:12 }}>Access (RBAC)</div>
        {[['Kyle R.','kyle@azx.io','Owner'],['Dana L.','dana@azx.io','Editor'],['eng-team','Entra group','Viewer']].map(([n,e,r])=>(
          <div key={e} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'1px solid var(--line)' }}>
            <div style={{ width:28, height:28, borderRadius:'50%', background:'var(--bg-3)', border:'1px solid var(--line-2)', display:'grid', placeItems:'center', fontSize:11, color:'var(--fg-2)' }}>{n[0]}</div>
            <div style={{ flex:1, minWidth:0 }}><div style={{ fontSize:13, fontWeight:500 }}>{n}</div><div className="mono" style={{ fontSize:10.5, color:'var(--fg-3)' }}>{e}</div></div>
            <Badge tone={r==='Owner'?'acc':'neutral'}>{r}</Badge>
          </div>
        ))}
        <Button variant="ghost" icon="plus" size="sm" style={{ marginTop:12, width:'100%' }}>Add member or group</Button>
      </Card>
      <Card style={{ borderColor:'var(--bad-dim)' }}>
        <div className="eyebrow" style={{ marginBottom:4, color:'var(--bad)' }}>Lifecycle</div>
        <p style={{ margin:'0 0 14px', fontSize:12.5, color:'var(--fg-3)', lineHeight:1.5 }}>Disabling returns <span className="mono">410 + Clear-Site-Data</span> and revokes capabilities at the gateway instantly. Subdomains are quarantined, never reused.</p>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          <Button variant="ghost" icon="clock" size="md" style={{ width:'100%', justifyContent:'flex-start' }}>Disable app</Button>
          <Button variant="danger" icon="x" size="md" style={{ width:'100%', justifyContent:'flex-start' }}>Archive & quarantine subdomain</Button>
        </div>
      </Card>
    </div>
  </div>;
}

// ---- Owner usage (aggregate) ---------------------------------------
function OwnerUsage(){
  return <div className="stagger">
    <PageHead eyebrow="Workspace" title="Usage" sub="Aggregate gateway activity across the apps you own — requests, LLM tokens, and storage."/>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card><Stat icon="bolt" label="Requests / day" value="29.5" unit="k"/></Card>
      <Card><Stat icon="cpu" label="LLM tokens / day" value="4.61" unit="M" sub="63% of 7.3M budget" tone="var(--warn)"/></Card>
      <Card><Stat icon="db" label="Storage" value="1.74" unit="GB"/></Card>
      <Card><Stat icon="user" label="Active users (7d)" value="116"/></Card>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--gap)', marginBottom:'var(--gap)' }}>
      <Card><div className="eyebrow" style={{ marginBottom:14 }}>Requests · 14 days</div><Bars data={PLATFORM.requests14d} h={130} color="var(--acc)"/></Card>
      <Card><div className="eyebrow" style={{ marginBottom:14 }}>LLM tokens · 14 days (M)</div><Bars data={PLATFORM.tokens14d} h={130} color="var(--info)"/></Card>
    </div>
    <Card>
      <div className="eyebrow" style={{ marginBottom:14 }}>By app · tokens today</div>
      {APPS.filter(a=>a.use.tokDay>0).sort((a,b)=>b.use.tokDay-a.use.tokDay).map(a=>{
        const pct = Math.round(a.use.tokDay/2_910_000*100);
        return <div key={a.id} style={{ display:'flex', alignItems:'center', gap:14, padding:'9px 0' }}>
          <span style={{ fontSize:13, width:150, fontWeight:500 }}>{a.name}</span>
          <div style={{ flex:1 }}><Meter pct={pct} tone="var(--info)"/></div>
          <span className="mono tnum" style={{ fontSize:12.5, width:70, textAlign:'right', color:'var(--fg-2)' }}>{fmt(a.use.tokDay)}</span>
        </div>;
      })}
    </Card>
  </div>;
}

Object.assign(window, { OwnerApps, AppDetail, OwnerUsage, Overlay, fmt });
