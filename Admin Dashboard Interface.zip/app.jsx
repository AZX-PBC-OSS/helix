// ============================================================
// AZX — top-level app: routing, role switch, deploy overlay, tweaks.
// ============================================================

const ACCENT_INK = { '#cdfa50':'#0b1000', '#5b9dff':'#04060d', '#ff8a4c':'#1a0800', '#b692ff':'#0f0626' };

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "nav": "sidebar",
  "deployFlow": "wizard",
  "accent": "#cdfa50",
  "density": "regular",
  "grid": true
}/*EDITMODE-END*/;

function App(){
  const [t,setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [role,setRole] = useState(()=> localStorage.getItem('azx_role') || 'owner');
  const [route,setRoute] = useState(()=> localStorage.getItem('azx_route') || 'apps');
  const [deployOpen,setDeployOpen] = useState(false);

  // persist
  useEffect(()=>{ localStorage.setItem('azx_role', role); },[role]);
  useEffect(()=>{ localStorage.setItem('azx_route', route); },[route]);

  // apply visual tweaks
  useEffect(()=>{
    const r = document.documentElement;
    r.setAttribute('data-density', t.density);
    r.style.setProperty('--acc', t.accent);
    r.style.setProperty('--acc-ink', ACCENT_INK[t.accent]||'#0b1000');
    document.querySelector('.az-backdrop').style.opacity = t.grid ? 1 : 0;
  },[t.density,t.accent,t.grid]);

  // role/route guard — leaving admin role exits admin routes
  const ADMIN_ROUTES = ['approvals','audit','platform','registry','violations'];
  useEffect(()=>{ if(role==='owner' && ADMIN_ROUTES.includes(route)) setRoute('apps'); },[role]);

  function go(r, extra){
    if(extra==='__deploy'){ setDeployOpen(true); return; }
    setRoute(r);
    document.querySelector('main')?.scrollTo({ top:0 });
  }
  const openDeploy = ()=>setDeployOpen(true);

  const ownerCounts = { apps: APPS.length, usage: null };
  const adminCounts = {
    approvals: APPROVALS.length, audit: null, platform: null,
    registry: APPS.length, violations: VIOLATIONS.filter(v=>!v.requested).length,
  };

  // route → element
  const current = route.startsWith('app:') ? 'apps' : route;
  function Screen(){
    if(route.startsWith('app:')) return <AppDetail id={route.slice(4)} go={go} openDeploy={openDeploy}/>;
    switch(route){
      case 'apps': return <OwnerApps go={go} openDeploy={openDeploy}/>;
      case 'usage': return <OwnerUsage/>;
      case 'approvals': return <AdminApprovals/>;
      case 'audit': return <AdminAudit/>;
      case 'platform': return <AdminPlatform/>;
      case 'registry': return <AdminRegistry go={go}/>;
      case 'violations': return <AdminViolations/>;
      default: return <OwnerApps go={go} openDeploy={openDeploy}/>;
    }
  }

  const Shell = t.nav==='topnav' ? TopnavShell : SidebarShell;
  return <>
    <Shell role={role} setRole={setRole} current={current} go={go}
      ownerCounts={ownerCounts} adminCounts={adminCounts}>
      <div key={route}><Screen/></div>
    </Shell>

    {deployOpen && <DeployFlow variant={t.deployFlow} onClose={()=>setDeployOpen(false)}/>}

    <TweaksPanel title="Tweaks">
      <TweakSection label="Navigation" />
      <TweakRadio label="App shell" value={t.nav} options={[{value:'sidebar',label:'Sidebar'},{value:'topnav',label:'Top nav'}]}
        onChange={v=>setTweak('nav',v)} />
      <TweakSection label="Deploy flow" />
      <TweakRadio label="Upload UX" value={t.deployFlow} options={[{value:'wizard',label:'Wizard'},{value:'command',label:'CLI-first'}]}
        onChange={v=>setTweak('deployFlow',v)} />
      <TweakSection label="Appearance" />
      <TweakColor label="Accent" value={t.accent}
        options={['#cdfa50','#5b9dff','#ff8a4c','#b692ff']}
        onChange={v=>setTweak('accent',v)} />
      <TweakRadio label="Density" value={t.density} options={['compact','regular','comfy']}
        onChange={v=>setTweak('density',v)} />
      <TweakToggle label="Blueprint grid" value={t.grid} onChange={v=>setTweak('grid',v)} />
    </TweaksPanel>
  </>;
}

// TweakRadio supports [id,label] pairs or plain strings
ReactDOM.createRoot(document.getElementById('root')).render(
  <><div className="az-backdrop"></div><App/></>
);
